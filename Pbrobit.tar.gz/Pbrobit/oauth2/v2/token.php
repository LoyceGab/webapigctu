<?php

// POST - Request method
// /oauth2/v2/token - Endpoint
// Parameter:
// Authorization: Basic + base64encode(client_id+":"+client_secret) -- passed through header

$authorization = apache_request_headers();
if(!isset($authorization['Authorization'])){
    header('HTTP/1.0 401 Unauthorized');
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(array("Error"=>"Missing Authorization Header"));
}
else{
        header('Content-Type: application/json; charset=utf-8');
        require("../../restriction/blacklist.php");


        $includes = array(
            "../../config/Connection.php",
            "../../controllers/token/token.php",
            "../../models/token/token.php"
        );

        $allowed_includes = array(
            "../../config/Connection.php",
            "../../controllers/token/token.php",
            "../../models/token/token.php"
        );

        $inc = new Blacklist();
        $inc->check($includes,$allowed_includes);

        $conn = new Connection();
        $conn = $conn->connects();


        $request_method = $_SERVER["REQUEST_METHOD"];
        $allowed_methods = array("POST");


    if($request_method == "POST"){
        $authorization_data = explode(" ",$authorization['Authorization']);    
        if(sizeof($authorization_data) == 2){
            $authorization_type = $authorization_data[0];
            $authorization_secret = $authorization_data[1];

            if($authorization_type != "Basic"){
                echo json_encode(array("Error"=>"Basic Authentication Required"));
            } else{

            $token = new TokenController($conn);
            $hasErrors = $token->verifyClient($authorization_secret);

            if($hasErrors == true){

                header("Cache-Control: no-store");
                header("Cache-Control: no-cache");

            if(isset($_POST['refresh_token'])){
            
            $refresh_token = $_POST['refresh_token'];
                $token->regenerateToken($authorization_secret,$refresh_token);
            }
            else{
                $token->generateToken($authorization_secret);
                    } 
            }
            }
        }
        else{
            echo json_encode(array("Error"=>"Authorization Not Accepted"));
        }
    }
    else{
        if(!in_array($request_method,$allowed_methods)){
            echo json_encode(array("Error" => "Request Method Not Allowed"));
        }
    }

}

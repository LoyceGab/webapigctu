<?php

// POST request

// parameters:
// - Client ID
// - Client 
// - Grant type
// - Authorization Code
// - Scope {optional}


// Response:
// Access Token and Refresh Token


// From Tutorial
// POST /oauth2/v2/token
// parameters:
// - client_id
// - client_secret
// - grant_type
// - redirect_uri
// - code {authorization code}


// Response
// - Access Token:
// - Refresh Token:
// - Expires in:
// - Scope:
// - Id Token: {Remove}


// From reading more from AUthentication Code Grant Type flow
// Parameter:
// grant_type - Required { authorization_code }
// authentication code - Required
// redirect_uri - Required
// client_id - Required


// Response:
// {
//     "access_token":"2YotnFZFEjr1zCsicMWpAA",
//     "token_type":"example",
//     "expires_in":3600,
//     "refresh_token":"tGzv3JOkF0XG5Qx2TlKWIA",
//     "example_parameter":"example_value"
//   }

require("../../restriction/blacklist.php");

$includes = array(
    "../../config/Connection.php"
);

$allowed_includes = array(
    "../../config/Connection.php"
);

// $inc = new \Blacklist();
$inc = new Blacklist();
$inc->check($includes,$allowed_includes);

// $headers = apache_request_headers();

$conn = new Connection();

$allowed_methods = array("GET","POST","PUT","DELETE");
$request_method = $_SERVER["REQUEST_METHOD"];


$uri = $_SERVER['REQUEST_URI'];
$url = explode("/",$uri);

if($request_method == "GET"){
    echo json_encode(array("error"=>"GET Request to token endpoint not possible"));
} else if($request_method == "POST"){
    echo json_encode(array("error"=>"GET Request to token endpoint not possible"));
} else if($request_method == "PUT"){
    echo json_encode(array("error"=>"GET Request to token endpoint not possible"));
} else{
    if(!in_array($request_method,$allowed_methods)){
        echo json_encode(array("method"=>"Not Allowed"));
    }
}



?>
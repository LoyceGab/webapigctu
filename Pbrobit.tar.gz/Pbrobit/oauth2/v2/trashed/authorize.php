<?php


// Big Notice
// Don't ever use this endpoint. The OAuth 2 grant flow type you should use is the 
// client credential grant type flow.

// You register with the payment gateway, create the app, get your client id and secret and 
// generate token which you will use in your app





// POST request

// parameters:
// response_type - required { code }
// client_id - required
// redirect_uri - optional
// scope - optional -- {openId profile purchase}
// state - Recommended

// Response:
// authorization_code
// state



// Notice
// Won't be using this endpoint. This one involves user in the authentication process
// and requires users to have account with the resource server also

?>
<?php
$card = 124324;
echo substr($card,0,1);
?>
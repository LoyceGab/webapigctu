<?php 

$authorization = apache_request_headers();
if(!isset($authorization['Authorization'])){
    echo json_encode(array("Error"=>"Authorization Required"));
}
else{

    $authorization_data = explode(" ",$authorization['Authorization']);    

    // Auth check start
    if(sizeof($authorization_data) == 2){
        $authorization_type = $authorization_data[0];
        $authorization_secret = $authorization_data[1];

        if($authorization_type != "Bearer"){
            echo json_encode(array("Error"=>"Authorization Type - Bearer Token Required"));
        }
        else{

            // $client_secret = new 
            $token = new TokenController($conn);
            echo $token->verifyClient($authorization_secret);

            if($authorization_secret != "accesstokem"){
                echo "sa";
            }else{
            
            require("../../../restriction/blacklist.php");
            header("Access-Control-Allow-Origin: http://localhost/Pbrobit/api/v1/");
            header("Content-Type: application/json; charset=UTF-8");
            header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
            header("Access-Control-Max-Age: 6000");
            header("X-Powered-By: PHP");
            // header("PHP_AUTH: Basic 1201Vb1");
            // header("WWW-Authenticate: Basic realm=\"My Realm\""); //Basic Auth Header - Should be removed later
            header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");


            // if(!isset($_SERVER['PHP_AUTH_USER'])) {
            //     header("WWW-Authenticate: Basic realm=\"My Realm\"");
            //     header("HTTP/1.0 401 Unauthorized");
            //     echo "Basic Authentication failed. Failed to provide Credentials\n";
            //     exit;
            // }
            // else {
            //     header("PHP_AUTH_USER:". $_SESSION["PHP_AUTH_USER"]);
            //   }
            
            // echo $_SERVER['REQUEST_METHOD'];
            // echo $_SERVER['PHP_AUTH_USER'];

$includes = array(
    "../../../config/Connection.php",
    "../../../controllers/token/token.php",
    "../../../controllers/payment/paymentController.php"
);

$allowed_includes = array(
    "../../../config/Connection.php",
    "../../../controllers/payment/paymentController.php"
);

// $inc = new \Blacklist();
$inc = new Blacklist();
$inc->check($includes,$allowed_includes);

// $headers = apache_request_headers();

$conn = new Connection();

$request_method = $_SERVER["REQUEST_METHOD"];


$uri = $_SERVER['REQUEST_URI'];
$url = explode("/",$uri);


$size_of_url = sizeof($url);

global $options;

if($size_of_url == 7){
    $id = $url[6];
    $options = array($id);
} else if($size_of_url == 8){
    $id = $url[6];
    $target =  $url[7];
    $options = array($id,$target);
}
else if($size_of_url == 6){
    $options = array();
}


$allowed_methods = array("GET","POST","PUT","DELETE");

// unset($_SERVER['PHP_AUTH_USER']);

if($request_method == "GET"){

    $data = new Payment();
    $data->gets($options,$conn);
    // echo sizeof($options);

    // if($option_size == 1){

    // }

    // if($id){
    //     $options[0] = $id;
    //     $data->gets($options,$conn);
    // }
    // else if($id || $targets){
    //     $options[0] = $id;
    //     $options[1] = $targets;

    //     // $data->gets($options,$conn);
    //     echo $id;
    // }
    // else{
    //     $data->get($conn);
    // }
}
else if($request_method == "PUT"){
        // $s = $v['Authorization'];
        // $in = explode(" ",$s);
        // echo $in[0];
    echo json_encode(array("name"=>"Susuassey Prog"));
} else if($request_method == "POST"){
    // $data = new Payment();
    // echo $url[6];
    // $data->post();
    // $data = json_decode(file_get_contents("php://input"));


    $data = file_get_contents("php://input");
    $card = $_POST["card_number"];
    $card_expiry = $_POST["card_expiry"];
    // $card_cvv = 
    $amount = $_POST['amount'];
    $payment_method = $_POST['payment_method'];
    echo "Amount is $amount <br>";
    echo "Payment Method is $payment_method";

    $payment = new Payment();
    $payment->post($amount,$payment_method,$conn);
    // $payment->update();
} else{
    if(!in_array($request_method,$allowed_methods)){
        echo json_encode(array("method"=>"Not Allowed"));
    }
}

            


// Payment Object Response
/*
Payment Id:
Object: Payment
Amount:
Payment method: Card
payment method options: Momo, Card
payment method types:  Ecobank, Mtn, Vodaphone, Tigo Cash, Fidelity, GCB
Card Number:
Card_Expiry_ Month:
Card_Expiry_ Year:
Card_CVC:
Phone Number:
Created:
currency:
metadata:
status:
client_secret:
customer_id
description:
*/
            }
        }



    } // Auth check end

    else{
        echo json_encode(array("Error"=>"Authorization Not Accepted"));
    }

}

?>
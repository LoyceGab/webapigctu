Every Creation of a data or Post request sent to a resource,
you must take the client id and save along the provided data.


When retrieving data, you must pass the client id 
as the where statement to get data for a specific client
and not for every app registered in the payment gateway.




Security Vulnerability: - Its okay. This is how it works.
Once someone has an access token for a client, the person
can have all information associated with that client.



One important information::
When the user selects the item from your eccomerce page,
the customer adds to cart and checks out.
Payment is made by customer using payment api.
Payment details is collected by gateway.
Payment details securely stored into gateway database.
Payment request is made to the card association depending on the card number given
Note:: Card number detaermines the card association(masercard or visa)
Card association then detects particular bank and sends request for payment
Bank checks the account details of the bank account using the ...
card number, card expiry and cvv and if possible bank account name
Bank checks the amount in the account and if its sufficient for the payment request.
If enough, success is returned else failed returned to the card association
Note:: if success, banks sends an authorization code known as OTP 
as confirmation of transaction/payment (in form ) to the account card holder using registered details
The card association then sends the response to the payment gateway.
The payment gateway then sends a screen to the user to enter OTP sent by bank if payment was allowed by bank
The user enters OTP and transaction is created in payment gateway.
The user is then redirected to the payment confirmed or order made successfully page on merchant(client) website
Then the whole process is done.


Note::
1. Transaction status can be successful if Card holder confirmes the OTP on merchant website
2. Transaction status can be failed if card holder doesn't have enough amount in bank
3. Transaction status can also be failed if cardholder enters wrong OTP during OTP confirmation
4. Transaction can be aborted if card holder cancels the OTP confirmation



Changes::

Refund takes the transaction reference not the payment because the transaction contains details
about the whole item bought and if transaction was made successfully or not.

Payment:
Add Card issuer to the payment database. It helps to determine which card association api should be called

Note that the payment api only contains information that is helpful to make payment request
to the necessary payment method selected.

Include an endpoint to make confirmation of payment

Include an endpoint to make cancellation of payment - Used when cardholder cancels confirmation of OTP
                                                    - When client enters the wrong OTP

If the payment status is cancelled, dont't forget to update the payment status using update endpoint

Include an endpoint to make update to payment status

Once the user enters the necessary details and clicks on pay,
a payment is created for the customer.

Depositor name and email is still useful to know who made the payment
Student ID is useful to know the student the payment is made for
Recipient name is useful to know who will receive the payment.

Payment Changes:
Please change receipient_name to receipient_account.

Add receipient_phonenumber as a helpful means to 
provide school's momo number if school chose Momo as payment method.

Note::
1. Recipient Account is added by merchant or client automatically to indicate the account number that will be
receiving the payment. The account number to be used will be that of the School.
2. Recipient Phone Number is added also by client automatically to indicate school's momo number to make
momo payment to.



Note::
Payment Api gets payment status from the bank. 
if failed, status is "failed". if payment was just created, status is "initiated" 
else if success, status is "Success"



Since Transaction is created after payment, transactio status is determined from payment api.



Big Note::
Since the payment gateway will have only one database and tables for every operation,
multiple project creation can show data of other clients in their dashboard.
So, fetch and insert data (adding client id)  using client id.
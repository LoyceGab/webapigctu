<?php
header("Content-Type: application/json");
// $options = array("transaction_type" => "School Fees","data" => array("name" => "Susuassey Wonder"));
// echo $options['transaction_type'];
// echo json_encode($options);
    class OTPGenerator{
        private $otp;


        public function generate(){
            $this->otp = random_int(100000,999999);
            return $this->otp;
        }
    }

    $otps = new OTPGenerator();
    $otp = $otps->generate();
    echo $otp;

?>
<?php

class Router{
    public function get($route,$method){
        if($method = "GET"){
            return true;
        }
    }
    public function post($uri,){
        
    }
}

$router = new Router();
// $router->get("/payment");

?>
CREATE TABLE OTP{
    `id` INT(200) AUTO_INCREMENT NOT NULL,
    `reference` varchar(255) DEFAULT NULL,
    `payment_reference` varchar(50) DEFAULT NULL,
    `phone_number` INT(15) DEFAULT NULL,
    `otp_value` INT(6) DEFAULT NULL,
    PRIMARY KEY(id)
};
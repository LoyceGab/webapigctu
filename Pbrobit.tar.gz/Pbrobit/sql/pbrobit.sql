 CREATE TABLE Arrears(
    id INT(50) AUTO_INCREMENT NOT NULL,
    reference VARCHAR(100) NULL,
    student_id INT(50) NULL,
    student_name VARCHAR(100) NULL,
    student_class VARCHAR(100) NULL,
    student_course VARCHAR(100) NULL,
    fees_owed INT(50) NULL,
    date_created INT NULL,
    PRIMARY KEY(id)
);


CREATE TABLE Payment(
    id INT(50) AUTO_INCREMENT NOT NULL,    
    reference VARCHAR(100) NULL,
    student_id VARCHAR(50) NULL,
    depositor_name VARCHAR(100) NULL,
    depositor_email VARCHAR(100) NULL,
    item_bought VARCHAR(100) NULL,
    recipient_accountnumber VARCHAR(100) NULL,
    recipient_phonenumber VARCHAR(15) NULL,
    payment_option VARCHAR(20) NULL,
    payment_method VARCHAR(20) NULL,
    amount VARCHAR(50) NULL,
    currency VARCHAR(20) NULL,
    card_issuer VARCHAR(15) NULL,
    card_number VARCHAR(100) NULL,
    card_expiry_month VARCHAR(50) NULL,
    card_expiry_year VARCHAR(50) NULL,
    card_cvv VARCHAR(50) NULL,
    phone_number VARCHAR(50) NULL,
    status_info VARCHAR(30) NULL,
    redirect_url VARCHAR(200) NULL,
    date_created INT(50) NULL,
    PRIMARY KEY(id)
);

CREATE TABLE `Refunds`(
    `id` INT(25) AUTO_INCREMENT NOT NULL,    
    `reference` VARCHAR(100) NULL,
    `transaction_reference` VARCHAR(100) NULL,
    `amount` INT(50) NULL,
    `currency` VARCHAR(20) NULL,
    `reason` TEXT(255) NULL,
    `date_created` VARCHAR(50) NULL,
    PRIMARY KEY(`id`)
);

CREATE TABLE Tokens(
    id INT(100) AUTO_INCREMENT NOT NULL,
    client_id VARCHAR(255) NULL,
    client_secret VARCHAR(255) NULL,
    grant_type VARCHAR(100) NULL,
    access_token VARCHAR(255) NULL,
    refresh_token VARCHAR(255) NULL,
    scope VARCHAR(100) NULL,
    expires INT(10) NULL,
    date_created INT(100) NULL,
    PRIMARY KEY(id)
);

CREATE TABLE `Transaction` (
 `id` int(255) NOT NULL AUTO_INCREMENT,
 `reference` varchar(255) DEFAULT NULL,
 `transaction_type` varchar(50) DEFAULT NULL,
 `payment_reference` varchar(50) DEFAULT NULL,
 `customer_name` varchar(100) DEFAULT NULL,
 `customer_phoneNumber` int(20) DEFAULT NULL,
 `customer_email` varchar(100) DEFAULT NULL,
 `item_bought` varchar(100) DEFAULT NULL,
 `student_id` varchar(50) DEFAULT NULL,
 `amount` int(50) DEFAULT NULL,
 `currency` varchar(20) DEFAULT NULL,
 `payment_method` varchar(20) DEFAULT NULL,
 `status_info` varchar(20) DEFAULT NULL,
 `refund_status` varchar(20) DEFAULT NULL,
 `date_created` int(30) DEFAULT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

create table Cart(
    id int auto_increment not null,
    customer_id varchar(100) not null,
    product_name varchar(100) not null,
    price int not null,
    image varchar(100) not null,
    primary key(id)
);

create table Orders(
    id int auto_increment not null,
    order_id int not null,
    product_name varchar(100) not null,
    price int not null,
    receiver varchar(50) null,
    customer_id varchar(40) not null,
    primary key(id)
);

CREATE TABLE Products(
    id int auto_increment not null,
    name varchar(100) not null,
    price int not null,
    image varchar(100) not null,
    category varchar(50) not null,
    primary key(id)
);
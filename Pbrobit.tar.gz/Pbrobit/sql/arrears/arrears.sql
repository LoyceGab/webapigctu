 CREATE TABLE Arrears(
    id INT(50) AUTO_INCREMENT NOT NULL,
    reference VARCHAR(100) NULL,
    student_id INT(50) NULL,
    student_name VARCHAR(100) NULL,
    student_class VARCHAR(100) NULL,
    student_course VARCHAR(100) NULL,
    fees_owed INT(50) NULL,
    date_created INT NULL,
    PRIMARY KEY(id)
);
CREATE TABLE `Transaction` (
 `id` int(255) NOT NULL AUTO_INCREMENT,
 `reference` varchar(255) DEFAULT NULL,
 `transaction_type` varchar(50) DEFAULT NULL,
 `payment_reference` varchar(50) DEFAULT NULL,
 `customer_name` varchar(100) DEFAULT NULL,
 `customer_phoneNumber` int(20) DEFAULT NULL,
 `customer_email` varchar(100) DEFAULT NULL,
 `item_bought` varchar(100) DEFAULT NULL,
 `student_id` varchar(50) DEFAULT NULL,
 `amount` int(50) DEFAULT NULL,
 `currency` varchar(20) DEFAULT NULL,
 `payment_method` varchar(20) DEFAULT NULL,
 `status_info` varchar(20) DEFAULT NULL,
 `refund_status` varchar(20) DEFAULT NULL,
 `date_created` int(30) DEFAULT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;
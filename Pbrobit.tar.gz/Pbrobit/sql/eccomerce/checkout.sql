create table Checkout(
    id int auto_increment not null,
    customer_id int not null,
    product_name varchar(100) not null,
    price int not null,
    image varchar(100) not null,
    primary key(id)
);
CREATE TABLE Products(
    id int auto_increment not null,
    name varchar(100) not null,
    price int not null,
    image varchar(100) not null,
    category varchar(50) not null,
    primary key(id)
);
create table Orders(
    id int auto_increment not null,
    order_id int not null,
    product_name varchar(100) not null,
    price int not null,
    receiver varchar(50) null,
    customer_id varchar(40) not null,
    primary key(id)
);
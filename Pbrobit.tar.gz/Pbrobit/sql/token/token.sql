CREATE TABLE Tokens(
    id INT(100) AUTO_INCREMENT NOT NULL,
    client_id VARCHAR(255) NULL,
    client_secret VARCHAR(255) NULL,
    grant_type VARCHAR(100) NULL,
    access_token VARCHAR(255) NULL,
    refresh_token VARCHAR(255) NULL,
    scope VARCHAR(100) NULL,
    expires INT(10) NULL,
    date_created INT(100) NULL,
    PRIMARY KEY(id)
)
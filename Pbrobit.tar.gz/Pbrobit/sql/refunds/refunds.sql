CREATE TABLE `Refunds`(
    `id` INT(25) AUTO_INCREMENT NOT NULL,    
    `reference` VARCHAR(100) NULL,
    `transaction_reference` VARCHAR(100) NULL,
    `amount` INT(50) NULL,
    `currency` VARCHAR(20) NULL,
    `reason` TEXT(255) NULL,
    `date_created` VARCHAR(50) NULL,
    PRIMARY KEY(`id`)
);
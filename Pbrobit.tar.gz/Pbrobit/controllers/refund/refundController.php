<?php 
class RefundController{

    private $conn;

public function __construct($conn){
    $this->conn = $conn;

}

public function getRefund($data){

    $refundModel = new RefundModel($this->conn);
    $result = $refundModel->getRefund($data);
    echo json_encode($result);

}

public function getRefunds(){

        $refundModel = new RefundModel($this->conn);
        $results = $refundModel->getRefunds();
        echo json_encode($results);
}

public function createRefund(){    

    $check = new Check();
    $transaction_reference = $check->check("transaction_reference",true);
        $amount =  $check->check("amount",true);
        $currency = $check->check("currency");
        $reason = $check->check("reason");

        // Required Parameters
        $required = array($transaction_reference,$amount);
        $validate = $check->validateRequired($required);
        if($validate == true){
            echo json_encode(array("Error" => "Some fields are required"));
        }else{
        $data = array(
            "transaction_reference" => $transaction_reference,
            "amount" => $amount,
            "currency" => $currency,
            "reason" => $reason
        );
        // var_dump($data);
    $refundModel = new RefundModel($this->conn);
    $result = $refundModel->createRefund($data);
    echo json_encode($result);

    }
    }

}

?>
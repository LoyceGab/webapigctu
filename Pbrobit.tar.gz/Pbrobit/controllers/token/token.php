<?php
class TokenController{

    private $client_id;
    private $client_secret;
    private $client_details;
    private $client_data;
    private $access_token;
    private $refresh_token;
    private $allowed_token_chars;
    private $conn;


    public function __construct($conn)
    {
        $this->conn = $conn;
        $this->allowed_token_chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-._~+';
        $this->access_token = substr(str_shuffle($this->allowed_token_chars),0,41);
        $this->refresh_token = substr(str_shuffle($this->allowed_token_chars),0,31);
    }

    // Client Details contains client id and client secret
    public function generateToken($client_details){

        $this->client_details = base64_decode("$client_details");
        if($this->client_details){
            $this->client_data = explode(":",$this->client_details);
            $this->client_id = $this->client_data[0];
            $this->client_secret = $this->client_data[1];

            $model = new TokenModel($this->conn);
            $result = $model->createToken($this->client_id,$this->access_token,$this->refresh_token);
            echo json_encode($result);
            }
    }

    public function verifyClient($given_token){
        $current_time = time();
            $model = new TokenModel($this->conn);
            $message = $model->getAccessToken();
            $generated_token_result = array();
            foreach ($message as $key) {
                $generated_token = $key['access_token'];
                array_push($generated_token_result,$generated_token);
            }
                if(in_array($given_token,$generated_token_result)){
                    $token_result = $model->getTokenExpiry($given_token);
                    $token_created_at = $token_result[0];
                    $token_expires = $token_result[1];
                    $diff = $current_time - $token_created_at;
                    if($diff <= $token_expires){
                                $client = $this->getClientByToken($given_token);
                                return array("client_id" => $client, "hasError" => false);
                        }else{
                            $model->deleteAccessToken($given_token);
                            return array("hasError" => true);
                                    }
                }
                else{
                    return array("hasError" => true);
                }
    }

    public function getClientByToken($given_token){
        $model = new TokenModel($this->conn);
        $result = $model->getClientByToken($given_token);
        return $result;
    }

    public function regenerateToken($client_details,$refresh_token){
        if($refresh_token){
            // calls the model and check if refresh token matches the one assigned to a client_id
            // remember basic authentication will be done where clients_details will be sent to make
            // verification


            $this->client_details = base64_decode("$client_details");
            if($this->client_details){
                $this->client_data = explode(":",$this->client_details);
                $this->client_id = $this->client_data[0];
                }
            $model = new TokenModel($this->conn);
            $message = $model->newToken($this->client_id,$this->access_token,$refresh_token);
            echo json_encode($message);
            // After verification, the generateToken function is called
        }
    }

}

?>
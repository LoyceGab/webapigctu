<?php 

header("Content-Type: application/json; charset=UTF-8");
class PaymentController{

    private $conn;

public function __construct($conn){
    $this->conn = $conn;
}

public function getPayment($data){

    $paymentModel = new PaymentModel($this->conn);
    $paymentModel->getPayment($data);
}

public function getPayments(){

    $paymentModel = new PaymentModel($this->conn);
    $result = $paymentModel->getPayments();
    echo json_encode($result);
    
    
}

public function createPayment(){
    $check = new Check();

    if($_SERVER["CONTENT_TYPE"] === "application/json"){
        $postData = json_decode(file_get_contents('php://input'), true);
        $datas = array();
        foreach ($postData as $key => $value) {
            $$key = $value;
            array_push($datas,$datas[$key] = $$key);
            }

            $fields = array("student_id","depositor_name","depositor_email","item_bought","recipient_accountnumber","recipient_phonenumber","payment_option","amount","currency","payment_method","card_number","card_expiry_month","card_expiry_year","card_cvv","phone_number","redirect_url");
            $data = array();
            forEach($fields as $field){
                $data[$field] = isset($datas[$field]) ? $datas[$field] : null;
            }

            $student_id = $check->checkJson($data["student_id"]);
            $depositor_name = $check->checkJson($data['depositor_name'],true);
            $depositor_email = $check->checkJson($data['depositor_email']);
            $item_bought = $check->checkJson($data['item_bought']);
            $merchant_account_number = $check->checkJson($data['recipient_accountnumber']);
            $recipient_phonenumber = $check->checkJson($data['recipient_phonenumber']);
            $payment_option = $check->checkJson($data['payment_option']);
            $payment_method = $check->checkJson($data['payment_method'],true);
            $amount = $check->checkJson($data['amount'],true);
            $currency = $check->checkJson($data['currency']);
            $phone_number = $check->checkJson($data['phone_number']);
            $redirect_url = $check->checkJson($data['redirect_url']);

            if($payment_method == "card"){
                $card_number = $check->checkJson($data['card_number'],true);
            $card_expiry_month = $check->checkJson($data['card_expiry_month'],true);
            $card_expiry_year = $check->checkJson($data['card_expiry_year'],true);
            $card_cvv = $check->checkJson($data['card_cvv'],true);
            $required = array($student_id,$depositor_name,$amount,$payment_method,$card_number,$card_expiry_month,$card_expiry_year,$card_cvv);
            }else{
                $card_number = $check->checkJson($data['card_number']);
                $card_expiry_month = $check->checkJson($data['card_expiry_month']);
                $card_expiry_year = $check->checkJson($data['card_expiry_year']);
                $card_cvv = $check->checkJson($data['card_cvv']);
            $required = array($student_id,$depositor_name,$amount,$payment_method);
            }

            // $required = array();


        }else{

        $student_id = $check->check("student_id",true);
        $depositor_name = $check->check("depositor_name",true);
        $depositor_email= $check->check("depositor_email");
        $item_bought = $check->check("item_bought");
        $merchant_account_number = $check->check("recipient_accountnumber");
        $recipient_phonenumber = $check->check("recipient_phonenumber");
        $payment_option= $check->check("payment_option");
        $payment_method= $check->check("payment_method", true);
        $amount= $check->check("amount",true);
        $currency= $check->check("currency");
        $phone_number= $check->check("phone_number");
        $redirect_url= $check->check("redirect_url");
        
        if($payment_method == "card"){
            $card_number= $check->check("card_number",true);
            $card_expiry_month= $check->check("card_expiry_month",true);
            $card_expiry_year= $check->check("card_expiry_year",true);
            $card_cvv= $check->check("card_cvv",true);
            $required = array($student_id,$depositor_name,$amount,$payment_method,$card_number,$card_expiry_month,$card_expiry_year,$card_cvv);
        }else{
            $card_number= $check->check("card_number");
        $card_expiry_month= $check->check("card_expiry_month");
        $card_expiry_year= $check->check("card_expiry_year");
        $card_cvv= $check->check("card_cvv");
        $required = array($student_id,$depositor_name,$amount,$payment_method);
        }

        $data = array(
            "student_id" => $student_id,
            "depositor_name" => $depositor_name,
            "depositor_email" => $depositor_email,
            "recipient_accountnumber" => $merchant_account_number, // Will be set by dev
            "recipient_phonenumber" => $recipient_phonenumber, // will be set by dev
            "payment_option" => json_encode($payment_option), // Provided by dev
            "payment_method" => $payment_method, // Provided by dev
            "item_bought" => json_encode($item_bought), // provided by dev
            "amount" => $amount, // Shows on Pay Button or provided by dev
            "currency" => isset($currency) ? $currency : "Ghc",
            "card_number" => $card_number,
            "card_expiry_month" => $card_expiry_month,
            "card_expiry_year" => $card_expiry_year,
            "card_cvv" => $card_cvv,
            "phone_number" => $phone_number,
            "redirect_url" => $redirect_url
        );

    }
    $merchant_account_number = isset($merchant_account_number) ? $merchant_account_number: 4215512341241231;
    $recipient_phonenumber = isset($receipient_phonenumber) ? $recipient_phonenumber : 233554513648;
        // Required Parameters
        $validate = $check->validateRequired($required);
        if($validate == true){
            echo json_encode(array("Error" => "Some fields are required"));
        }else{
                    $request_url = "www.pbrobit.com/third-party/card-schemes/visa/api/v1/authorization/authorization";
                    $request_data = array("merchant_account_number" => $merchant_account_number,"amount" => $amount,"card_number" => $card_number,"card_expiry_month" => $card_expiry_month,"card_expiry_year" => $card_expiry_year,"card_cvv" => $card_cvv);
                    $response = new Request($request_url,"POST",$request_data);


                    // Decode response from payment request
                    $json_outputs = json_decode($response,true);
                    
                    $processing_error = isset($json_outputs["exists"]) ? $json_outputs["exists"] : null;                    
                    
                    if($processing_error !== "false"){

                        // Create Payment
                        $paymentModel = new PaymentModel($this->conn);
                        $result = $paymentModel->createPayment($data);
                        // return array($result,$json_outputs);
                        // echo json_encode($result);


                        // Decode Payment Response
                        forEach($result as $payment_result){
                            $payment_reference = $payment_result["reference"];
                        }

                        if($_SERVER['CONTENT_TYPE'] === "application/json"){
                        $customer_phoneNumber = $payment_result["phone_number"];
                        $customer_name = $payment_result["depositor_name"];
                        $customer_email = $payment_result["depositor_email"];
                        $transaction_type = isset($student_id) ? "Fees" : "Product";
                        $payment_reference = $payment_reference;
                        $status = $json_outputs["status"] == "Approved" ? "Succeeded" : "Failed";

                        
                        }
                        else{
                        $customer_name = $_POST["customer_name"] = $payment_result["depositor_name"];
                        $customer_email = $_POST["customer_email"] = $payment_result["depositor_email"];
                        $customer_phoneNumber = $_POST["customer_phoneNumber"] = $payment_result["phone_number"];
                        $transaction_type = $_POST["transaction_type"] = isset($student_id) ? "Fees" : "Product";
                        $payment_reference = $_POST["payment_reference"] = $payment_reference;
                        $status = $_POST["status"] = $json_outputs["status"] == "Approved" ? "Succeeded" : "Failed";
                        }
                        $transaction_data = array(
                            "transaction_type" => $transaction_type,
                            "payment_reference" => $payment_reference,
                            "customer_name" => $customer_name,
                            "customer_email" => $customer_email,
                            "customer_phoneNumber" => $customer_phoneNumber,
                            "item_bought" => $item_bought,
                            "student_id" => $student_id,
                            "amount" => $amount,
                            "currency" => $currency,
                            "payment_method" => $payment_method,
                            "status" => $status
                            );
                        
                        $transaction = new transactionController($this->conn);
                        $tranresult = $transaction->createTransaction($transaction_data);

                        // $paymentModel->c
                        $paymentModel = new PaymentModel($this->conn);
                        $paymentModel->addStatus(array("status"=>$status,"reference" => $payment_reference));
                        if($status == "Succeeded"){
                            $arrearsModel = new ArrearsModel($this->conn);
                            $student_arrears = $arrearsModel->getArrear(array("student_id" => $student_id));
                            if(!empty($student_arrears)){
                                forEach($student_arrears as $student_arrear){
                                    $student_arrear_reference = isset($student_arrear["reference"]) ? $student_arrear["reference"] : null;
                                    $student_arrear_amount = isset($student_arrear["fees_owed"]) ? $student_arrear["fees_owed"] : 0;
                                }
                                $new_student_fees = $student_arrear_amount - $amount;
                                $arrearsModel->updateArrear(array("student_id" => $student_id,"reference" => $student_arrear_reference, "fees_owed" => $new_student_fees));
                            }
                            
                        }
                        echo json_encode(array("payment_details" => $result,"payment_status" => $json_outputs, "transaction_details" => $tranresult));
                        
                        
                    }else{
                        echo json_encode(array("payment_status" => "Failed", "Description" => "Card Not Valid"));
                    }

        }

    

}

public function confirmPayment($otp){
    $paymentModel = new PaymentModel($this->conn);
    $paymentModel->createPayment($otp);
}

// Payment endpoint makes call to visa and passes payment details along with merchant's account_number
// so that he can be paid after authorization

}

?>
<?php
class TransactionController{
    private $conn;

    public function __construct($conn){
        $this->conn = $conn;
    }

    public function getTransaction($data){
        $transactionModel = new TransactionModel($this->conn);
        $result = $transactionModel->getTransaction($data);
        echo json_encode($result);
        
    }

    public function getTransactions(){
        $transactionModel = new TransactionModel($this->conn);
        $result = $transactionModel->getTransactions();
        echo json_encode($result);
        
    }

    public function createTransaction($transData){
        // Checker instance
        $check = new Check();

        if($_SERVER['CONTENT_TYPE'] === "application/json"){
        $transaction_type =  $check->checkJson($transData["transaction_type"],true);
        $payment_reference = $check->checkJson($transData["payment_reference"],true);
        $customer_name = $check->checkJson($transData["customer_name"]);
        $customer_phoneNumber = $check->checkJson($transData["customer_phoneNumber"]);
        $customer_email = $check->checkJson($transData["customer_email"]);
        $item_bought = $check->checkJson($transData["item_bought"]);
        $student_id = $check->checkJson($transData["student_id"]);
        $amount = $check->checkJson($transData["amount"]);
        $currency = $check->checkJson($transData["currency"]);
        $payment_method = $check->checkJson($transData["payment_method"],true);
        $status = $check->checkJson($transData["status"]);

        }else{
            $transaction_type =  $check->check("transaction_type",true);
            $payment_reference = $check->check("payment_reference",true);
            $customer_name = $check->check("customer_name");
            $customer_phoneNumber = $check->check("customer_phoneNumber");
            $customer_email = $check->check("customer_email");
            $item_bought = $check->check("item_bought");
            $student_id = $check->check("student_id");
            $amount = $check->check("amount");
            $currency = $check->check("currency");
            $payment_method = $check->check("payment_method",true);
            $status = $check->check("status");
        }

        // Required Parameters
        $required = array($transaction_type,$payment_reference,$payment_method);
        $validate = $check->validateRequired($required);
        if($validate == true){
            echo json_encode(array("Error" => "Some fields are required"));
        }else{

        $data = array(
            "transaction_type" => $transaction_type,
            "payment_reference" => $payment_reference,
            "customer_name" => $customer_name,
            "customer_phoneNumber" => $customer_phoneNumber,
            "customer_email" => $customer_email,
            "item_bought" => json_encode($item_bought),
            "student_id" => $student_id,
            "amount" => $amount,
            "currency" => $currency,
            "payment_method" => $payment_method,
            "status" => $status
        );

        $transactionModel = new TransactionModel($this->conn);
        $result = $transactionModel->createTransaction($data);
        return $result;
    }
        
    }

    public function update(){
        
    }
    public function delete(){

    }
}


?>
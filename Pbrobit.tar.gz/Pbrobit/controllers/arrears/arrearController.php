<?php 
class ArrearController{

    private $conn;

public function __construct($conn){
    $this->conn = $conn;

}

public function createArrear(){
    $check = new Check();
    if($_SERVER['CONTENT_TYPE'] === "application/json"){

        $postData = json_decode(file_get_contents('php://input'), true);
        $datas = array();
        foreach ($postData as $key => $value) {
            $$key = $value;
            array_push($datas,$datas[$key] = $$key);
            }

            $fields = array("student_id","student_name","student_class","student_course","fees_owed");
            $data = array();
            forEach($fields as $field){
                $data[$field] = isset($datas[$field]) ? $datas[$field] : null;
            }

        $student_id = $check->checkJson("student_id",true);
        $student_name = $check->checkJson("student_name");
        $student_class = $check->checkJson("student_class");
        $student_course = $check->checkJson("student_course");
        $fees_owed = $check->checkJson("fees_owed",true);
    }else{
    $student_id = $check->check("student_id",true);
    $student_name = $check->check("student_name");
    $student_class = $check->check("student_class");
    $student_course = $check->check("student_course");
    $fees_owed = $check->check("fees_owed",true);

    $data = array(
        "student_id" => $student_id,
        "student_name" => $student_name,
        "student_class" => $student_class,
        "student_course" => $student_course,
        "fees_owed" => $fees_owed
    );
    }

    // Required Parameters
    $required = array($student_id,$fees_owed);
    $validate = $check->validateRequired($required);
    if($validate == true){
        echo json_encode(array("Error" => "Some fields are required"));
    }else{
    $arrearModel = new ArrearsModel($this->conn);
    $result = $arrearModel->createArrear($data);
    echo json_encode($result);
    }
}

public function getArrear($data){

    $arrearModel = new ArrearsModel($this->conn);
    $result = $arrearModel->getArrear($data);
    echo json_encode($result);

}

public function getArrears(){
    $arrearModel = new ArrearsModel($this->conn);
    $result = $arrearModel->getArrears();
    echo json_encode($result);
}


public function updateArrear($data){
    $arrearModel = new ArrearsModel($this->conn);
    $arrearModel->getArrears($data);
}

public function deleteArrear($data){
    $arrearModel = new ArrearsModel($this->conn);
    $result = $arrearModel->deleteArrear($data);
    echo json_encode($result);
}

}

?>
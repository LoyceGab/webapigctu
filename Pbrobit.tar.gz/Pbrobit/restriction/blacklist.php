<?php

class Blacklist{
    private $includes;
    private $allowed_includes;

    public function check($includes,$allowed_includes){
        $this->includes = $includes;
        $this->allowed_includes = $allowed_includes;

        foreach ($this->includes as $file) {
            if(in_array($file, $this->allowed_includes)){
             require($file);            
               }
             }         
    }
}
?>
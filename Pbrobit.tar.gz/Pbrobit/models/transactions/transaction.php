<?php

class TransactionModel{
    
    // Table Name
    private $table = "Transaction";

    //Connection string
    private $conn;

    public function __construct($conn){
        $this->conn = $conn;
    }

    public function getTransaction($data){
        $reference = $data['reference'];
        $selected_fields = "reference,transaction_type,payment_reference,customer_name,customer_phoneNumber,customer_email,item_bought,student_id,amount,currency,payment_method,status_info,date_created";
        try{
        $query = "SELECT $selected_fields FROM $this->table WHERE reference = :reference";
        $statement = $this->conn->prepare($query);
        $statement->execute(array(
            ":reference" => $reference
        ));
        $result = $statement->fetchAll(PDO::FETCH_ASSOC);
        return $result;
        } catch (PDOException $e){
            echo $e->getMessage()();
        }
    }

    public function getTransactions(){
        $selected_fields = "reference,transaction_type,payment_reference,customer_name,customer_phoneNumber,customer_email,item_bought,student_id,amount,currency,payment_method,status_info,date_created,refund_status";
        try{
            $query = "SELECT $selected_fields FROM $this->table";
            $statement = $this->conn->prepare($query);
            $statement->execute();
            $result = $statement->fetchAll(PDO::FETCH_ASSOC);
            return $result;
        } catch (PDOException $e){
        echo $e->getMessage()();
        }
    }


    public function createTransaction($data){        
        $referenceGenerator = new ReferenceGenerator();
        
        $date_created = time();
        $reference = $referenceGenerator->generate();
        $transaction_type = $data['transaction_type'];
        $payment_reference = $data['payment_reference'];
        $customer_name = $data['customer_name'];
        $customer_phoneNumber = $data['customer_phoneNumber'];
        $customer_email = $data['customer_email'];
        $item_bought = $data['item_bought'];
        $student_id = $data['student_id'];
        $amount = $data['amount'];
        $currency = $data['currency'];
        $payment_method = $data['payment_method'];
        $status_info = $data['status'];  // Transaction Status is gotten from payment api after call to bank api or OTP confirmation
        $date_created = $date_created;


        try {
            $query = "INSERT INTO $this->table (reference,transaction_type,payment_reference,customer_name,customer_phoneNumber,customer_email,item_bought,student_id,amount,currency,payment_method,status_info,date_created) 
            VALUES (:reference,:transaction_type,:payment_reference,:customer_name,:customer_phoneNumber,:customer_email,:item_bought,:student_id,:amount,:currency,:payment_method,:status_info,:date_created)";
            $statement = $this->conn->prepare($query);
            $result = $statement->execute(
                array(
                    ":reference" => $reference,
                    ":transaction_type" => $transaction_type,
                    ":payment_reference" => $payment_reference,
                    ":customer_name" => $customer_name,
                    ":customer_phoneNumber" => $customer_phoneNumber,
                    ":customer_email" => $customer_email,
                    ":item_bought" => $item_bought,
                    ":student_id" => $student_id,
                    ":amount" => $amount,
                    ":currency" => $currency,
                    ":payment_method" => $payment_method,
                    ":status_info" => $status_info,
                    ":date_created" => $date_created
                )
            );

            $posted_data = array("reference" => $reference);
            return $this->getTransaction($posted_data);

        } catch (PDOException $e) {
            echo $e->getMessage();
        }
        
    }

    public function addRefundStatus($data){
        $transaction_reference = $data['reference'];
        $status = $data['refund_status'];
        $query = "UPDATE $this->table SET refund_status=:refund_status WHERE reference=:reference";
        $statement = $this->conn->prepare($query);
        $statement->execute(array(':refund_status' => $status, ':reference' => $transaction_reference));
}


}

?>
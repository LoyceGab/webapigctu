<?php
class RefundModel{

    // Database table name
    private $table = "Refunds";

    // Connection
    private $conn;
    
    public function __construct($conn)
    {
        $this->conn = $conn; 

    }

    // Get all refunds made
    public function getRefunds(){
        $limit = 5;
        $selected_fields = "reference,transaction_reference,amount,currency,reason,date_created";

        try {
            $query = "SELECT $selected_fields FROM $this->table LIMIT :limited";
            $statement = $this->conn->prepare($query);
            $statement->bindParam(':limited', $limit, PDO::PARAM_INT);
            $statement->execute();
            $result = $statement->fetchAll(PDO::FETCH_ASSOC);
            return $result;
        } catch (PDOException $e) {
            $e->getMessage();
        }
    }

    // Get refunds made to a specific account using the refund reference
    public function getRefund($data){
        $reference = $data['reference'];
        $selected_fields = "reference,transaction_reference,amount,currency,reason,date_created";

        try {
            $query = "SELECT $selected_fields FROM $this->table reference=:reference";
            $statement = $this->conn->prepare($query);
            $statement->execute(array(
                ":reference" => $reference
            ));
            $result = $statement->fetchAll(PDO::FETCH_ASSOC);
            return $result;
        } catch (PDOException $e) {
            $e->getMessage();
        }
    }

    public function createRefund($data){
        $referenceGenerator = new ReferenceGenerator();
        $reference = $referenceGenerator->generate();
        $transaction_reference = $data['transaction_reference'];
        $amount = $data['amount'];
        $currency = $data['currency'];
        $reason = $data['reason'];
        $date_created = time();
        
        try {
            $query = "INSERT INTO $this->table(reference,transaction_reference,amount,currency,reason,date_created) VALUES(:reference,:transaction_reference,:amount,:currency,:reason,:date_created)";
            $statement = $this->conn->prepare($query);
            $statement->execute(
                array(
                    ":reference" => $reference,
                    ":transaction_reference" => $transaction_reference,
                    ":amount" => $amount,
                    ":currency" => $currency,
                    ":reason" => $reason,
                    ":date_created" => $date_created
                    )
            );

            $result = array("reference" => $reference);
            return $this->getRefund($result);
            
        } catch (PDOException $e) {
            $e->getMessage();
        }
    }

    // public function updateRefund($id,$metadata){
    //     try {
    //         $query = "UPDATE $this->table SET metadata=:metadata WHERE id= :id";
    //         $statement = $this->conn->prepare($query);
    //         $statement->execute(
    //             array(
    //                 ":id" => $id,
    //                 ":metadata" => $metadata,
    //                 )
    //         );
    //     } catch (PDOException $e) {
    //         $e->getMessage();
    //     }
    // }
}
?>
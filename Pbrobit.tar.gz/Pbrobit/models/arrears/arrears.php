<?php
class ArrearsModel{

    // Database table name
    private $table = "Arrears";

    // Connection
    private $conn;
    
    public function __construct($conn)
    {
        $this->conn = $conn;

    }

    public function createArrear($data){

        $referenceGenerator = new  ReferenceGenerator();
        $reference = $referenceGenerator->generate();

        $student_id = $data['student_id'];
        $student_name = $data['student_name'];
        $student_class = $data['student_class'];
        $student_course = $data['student_course'];
        $fees_owed = $data['fees_owed'];
        $date_created = time();

        try {
            $query = "INSERT INTO $this->table(reference,student_id,student_name,student_class,student_course,fees_owed,date_created)
            VALUES (:reference,:student_id,:student_name,:student_class,:student_course,:fees_owed,:date_created)";
            $statement = $this->conn->prepare($query);
            $statement->execute(
                array(
                    ":reference" => $reference,
                    ":student_id" => $student_id,
                    ":student_name" => $student_name,
                    ":student_class" => $student_class,
                    ":student_course" => $student_course,
                    ":fees_owed" => $fees_owed,
                    ":date_created" => $date_created
                )
            );

            $result = array("student_id" => $student_id);
            return $this->getArrear($result);
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
    }

    // Get all owed arrears of school fees
    public function getArrears(){
        $selected_fields = "reference,student_id,student_name,student_class,student_course,fees_owed,date_created";
        try {
            $query = "SELECT $selected_fields FROM $this->table";
            $statement = $this->conn->prepare($query);
            $statement->execute();
            $result = $statement->fetchAll(PDO::FETCH_ASSOC);
            return $result;
        } catch (PDOException $e) {
            $e->getMessage();
        }
    }

    // Get owed arrears of school fees by a specific students or by student id
    public function getArrear($data){
        $student_id = $data['student_id'];
        $selected_fields = "reference,student_id,student_name,student_class,student_course,fees_owed,date_created";
        try {
            $query = "SELECT $selected_fields FROM $this->table WHERE student_id=:student_id";
            $statement = $this->conn->prepare($query);
            $statement->execute(array(
                ":student_id" => $student_id
            ));
            $result = $statement->fetchAll(PDO::FETCH_ASSOC);
            return $result;
        } catch (PDOException $e) {
            $e->getMessage();
        }
    }

    public function updateArrear($data){
        $reference = $data['reference'];
        $student_id = $data['student_id'];
        $fees_owed = $data['fees_owed'];
        try {
            $query = "UPDATE $this->table SET fees_owed=:fees_owed WHERE student_id=:student_id AND reference=:reference";
            $statement = $this->conn->prepare($query);
            $statement->execute(
                array(
                    ":reference" => $reference,
                    ":student_id" => $student_id,
                    ":fees_owed" => $fees_owed
                    )
            );
            $result = array("student_id" => $student_id);
            return $this->getArrear($result);
        } catch (PDOException $e) {
            $e->getMessage();
        }
    }

    public function deleteArrear($data){
        if($this->checkStudent($data) > 0){
            $student_id = $data['student_id'];
            try {
                $query = "DELETE FROM $this->table WHERE student_id=:student_id";
                $statement = $this->conn->prepare($query);
                $statement->execute(array(
                    ":student_id" => $student_id
                ));
                $result = array("Message" => "Student Arrears has been deleted successfully");
                return $result;
            } catch (PDOException $e) {
                $e->getMessage();
            }
        } else{
            return array("Error" => "Student doesn't exist");            
        }
    }

    private function checkStudent($data){
        $student_id = $data['student_id'];
        try {
            $query = "SELECT * FROM $this->table WHERE student_id=:student_id";
            $statement = $this->conn->prepare($query);
            $statement->execute(array(
                ":student_id" => $student_id
            ));
            return $statement->rowCount();
        } catch (PDOException $e) {
            $e->getMessage();
        }
    }

}
?>
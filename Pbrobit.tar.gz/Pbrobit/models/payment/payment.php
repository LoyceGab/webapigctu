<?php

class PaymentModel{

    // Database table name
    private $table = "Payment";
    // private $otp_table = "OTP";

    // Connection
    private $conn;
    
    public function __construct($conn)
    {
        $this->conn = $conn; 
        // echo "sas";

    }

    public function createPayment($data){

            // Reference Generator Instance
            $referenceGenerator = new ReferenceGenerator();

            // Take the client id and insert along data. it makes us fetch only the data meant
            // for client and not everyone

            // Encrypt Card Details
            $encrypt_card = new Encrypt();

            $reference = $referenceGenerator->generate();
            $student_id = $data['student_id'];
            $depositor_name = $data['depositor_name'];
            $depositor_email = $data['depositor_email'];
            $item_bought = $data['item_bought'];
            $recipient_accountnumber = $data['recipient_accountnumber'];
            $recipient_phonenumber = $data['recipient_phonenumber'];
            $payment_option = $data['payment_option'];
            $payment_method = $data['payment_method'];
            $amount = $data['amount'];
            $currency = $data['currency'];
            $card_number = $data['card_number'];
            $card_expiry_month = $data['card_expiry_month'];
            $card_expiry_year = $data['card_expiry_year'];
            $card_cvv = $data['card_cvv'];
            $phone_number = $data['phone_number'];
            $redirect_url = $data['redirect_url'];
            $status_info = "Pending"; // Status info is gotten from bank 
            $date_created = time();

            if(substr($card_number,0,1) == 4){
                $issuer = "Visa";
            }
            else if(substr($card_number,0,1) == 5){
                $issuer = "Mastercard";
            }
            else{
                $issuer = null;
            }

            // Encrypted Card Details
            $card_number_encrypted = isset($card_number) ? $encrypt_card->encrypt3Des($card_number) : $card_number;
            $card_expiry_month_encrypted = isset($card_expiry_month) ? $encrypt_card->encrypt3Des($card_expiry_month) : $card_expiry_month;
            $card_expiry_year_encrypted = isset($card_expiry_year) ? $encrypt_card->encrypt3Des($card_expiry_year) : $card_expiry_year;
            $card_cvv_encrypted = isset($card_cvv) ? $encrypt_card->encrypt3Des($card_cvv) : $card_cvv;


        try {
            $query = "INSERT INTO $this->table(reference,student_id,depositor_name,depositor_email,item_bought,recipient_accountnumber,recipient_phonenumber,payment_option,payment_method,amount,currency,card_issuer,card_number,card_expiry_month,card_expiry_year,card_cvv,phone_number,redirect_url,date_created)
            VALUES(:reference,:student_id,:depositor_name,:depositor_email,:item_bought,:recipient_accountnumber,:recipient_phonenumber,:payment_option,:payment_method,:amount,:currency,:card_issuer,:card_number_encrypted,:card_expiry_month_encrypted,:card_expiry_year_encrypted,:card_cvv_encrypted,:phone_number,:redirect_url,:date_created)";
            $statement = $this->conn->prepare($query);
            $result = $statement->execute(
                array(
                        ':reference' => $reference,
                        ':student_id' => $student_id,
                        ':depositor_name' => $depositor_name,
                        ':depositor_email' => $depositor_email,
                        ':item_bought' => $item_bought,
                        ':recipient_accountnumber' => $recipient_accountnumber,
                        ':recipient_phonenumber' => $recipient_phonenumber,
                        ':payment_option' => $payment_option,
                        ':payment_method'  => $payment_method,
                        ':amount' => $amount,
                        ':currency' => $currency,
                        ':card_issuer' => $issuer,
                        ':card_number_encrypted' => $card_number_encrypted,
                        ':card_expiry_month_encrypted' => $card_expiry_month_encrypted,
                        ':card_expiry_year_encrypted' => $card_expiry_year_encrypted,
                        ':card_cvv_encrypted' => $card_cvv_encrypted,
                        ':phone_number' => $phone_number,
                        ':redirect_url' => $redirect_url,
                        ':date_created' => $date_created
                )
            );

            // if($result){
            //     $this->addStatus($status_info);
            // }
            // else{
            //     $this->addStatus("Failed");
            // }
            $posted_data = array("reference" => $reference);
            return $this->getPayment($posted_data);

        } catch (PDOException $e) {
            $e->getMessage();
        }
        
    }

    public function addStatus($data){
            $reference = $data['reference'];
            $status = $data['status'];
            $query = "UPDATE $this->table SET status_info=:status_info WHERE reference=:reference";
            $statement = $this->conn->prepare($query);
            $statement->execute(array(':status_info' => $status, ':reference' => $reference));
    }

    public function getPayments(){
        $selected_fields = "reference,student_id,depositor_name,depositor_email,item_bought,recipient_accountnumber,recipient_phonenumber,payment_option,payment_method,amount,currency,card_issuer,card_number,card_expiry_month,card_expiry_year,card_cvv,phone_number,redirect_url,date_created,status_info";
        try{
            $query = "SELECT $selected_fields FROM $this->table";
            $statement = $this->conn->prepare($query);
            $statement->execute();
            $result = $statement->fetchAll(PDO::FETCH_ASSOC);
            return $result;
        } catch(PDOException $e){
            echo $e->getMessage();
        }
    }

    public function getPayment($data){
        $reference = $data['reference'];

        $selected_fields = "reference,student_id,depositor_name,depositor_email,item_bought,recipient_accountnumber,recipient_phonenumber,payment_option,payment_method,amount,currency,card_issuer,card_number,card_expiry_month,card_expiry_year,card_cvv,phone_number,redirect_url,date_created";

        try{
            $query = "SELECT $selected_fields FROM $this->table WHERE reference = :reference";
            $statement = $this->conn->prepare($query);
            $statement->execute(
                array(
                    ":reference" => $reference
                )
            );
            $result = $statement->fetchAll(PDO::FETCH_ASSOC);
            return $result;
        } catch(PDOException $e){
            echo $e->getMessage();
        }
    }

    // public function getPostedPayment($data){
    //     $client_id = $data['client_id'];
    //     $reference = $data['reference'];
    //     try{
    //         $query = "SELECT * FROM $this->table WHERE reference = :reference AND client_id = :client_id";
    //         $statement = $this->conn->prepare($query);
    //         $statement->execute(
    //             array(
    //                 ":reference" => $reference,
    //                 ":client_id" => $client_id
    //             )
    //         );
    //         $result = $statement->fetchAll(PDO::FETCH_ASSOC);
    //         return $result;
    //     } catch(PDOException $e){
    //         echo $e->getMessage();
    //     }
    // }

    // public function confirmPayment($otp){
    //     try {
    //         $query = "SELECT * $this->otp_table";
    //         $statement= $this->conn->prepare($query);
    //         $result = $statement->execute();
    //         return $result;
    //     } catch (PDOException $e) {
    //         echo $e->getMessage();
    //     }
    // }

}

?>
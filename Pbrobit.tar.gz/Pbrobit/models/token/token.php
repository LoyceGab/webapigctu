<?php

class TokenModel{
    private $refreshToken;
    private $client_id;
    private $client_secret;
    private $access_token;

    public function __construct($conn)
    {
        $this->conn = $conn;

    }

    // This function is used to add new generated token into database - First called
    public function createToken($client_id,$access_token,$refresh_token){
        try{

            $this->access_token = $access_token;
            $this->refresh_token = $refresh_token;

            $token_result = array();

            // Check if both exists already, it true, just return value from database
            // else generate new token and add to database;
            if($this->getClient($client_id) == 0){
                $message = "Client Doesn't Exist";
                $token_result = array("Error" => $message);
                return $token_result;
            } else if($this->getClient($client_id) > 0){
                    $result = $this->getClientToken(($client_id));
                    foreach ($result as $row_data) {
                        $access_token = $row_data['access_token'];
                        $refresh_token = $row_data['refresh_token'];
                    }
                    if($access_token != null && $refresh_token != null){
                        $token_result = array(
                            "grant_type" => "client_credential",
                            "access_token"=>$access_token,
                            "token_type" => "bearer",
                            "expires_in" => 3600,
                            "refresh_token" => $refresh_token
                                        );
                        return $token_result;
                    }
                    else{
                        $time = time();
                        $query = "UPDATE RegisteredApps SET access_token=:access_token, refresh_token=:refresh_token, token_created_at=:token_created_at WHERE client_id=:client_id";
                        $statement = $this->conn->prepare($query);
                        $statement->execute(
                        array(
                            ":client_id" => $client_id,
                            ":refresh_token" => $this->refresh_token,
                            ":access_token" => $this->access_token,
                            ":token_created_at" => $time
                            )
                    );

                    $token_result = array(
                        "grant_type" => "client_credential",
                        "access_token"=>$this->access_token,
                        "token_type" => "bearer",
                        "expires_in" => 3600,
                        "refresh_token" => $this->refresh_token
                                    );
                    return $token_result;
                
                    }
            }

        } catch(PDOException $exception){
            echo $exception->getMessage();
        }
    }
    
    public function checkTokenAvailability($access){

    }

    

    // Verify client's identity before issueing a new access token after its' expiry
    public function verifyRefreshToken($refreshToken,$client_id){
        try{
            $this->refreshToken = $refreshToken;
            $query = "SELECT refresh_token FROM RegisteredApps WHERE client_id=:client_id";
            $statement = $this->conn->prepare($query);
            $statement->execute(
                array(":client_id" => $client_id)
            );
            $result = $statement->fetchAll(PDO::FETCH_ASSOC);
            foreach ($result as $data) {
                return $data['refresh_token'];
            }
            // return $result;

        } catch(PDOException $exception){
            echo $exception->getMessage();
        }
    }

    // Get new access token after it has expired
    public function newToken($client_id,$access_token,$refresh_token){
        $this->access_token = $access_token;
        $refresh_token_data = $this->verifyRefreshToken($refresh_token,$client_id);
        if($refresh_token === $refresh_token_data){
                try{
                $query = "UPDATE RegisteredApps SET access_token=:access_token WHERE client_id=:client_id AND refresh_token=:refresh_token";
                    $statement = $this->conn->prepare($query);
                    $statement->execute(
                        array(
                            ":client_id" => $client_id,
                            ":refresh_token" => $refresh_token,
                            ":access_token" => $this->access_token
                            )
                    );
                    return array(
                        "Success" => "Access Token Generated Successfully",
                        "Access Token" => $this->access_token
                    );
                
                } catch(PDOException $exception){
                    echo $exception->getMessage();
                    }
        }
        else{
            $message = array("Error" => "Refresh Token not valid");
            return $message;
        }
    }

    // Revokes the access token - Once access token is revoked, refresh token also is revoked
    public function revokeAccess($client_id){
        try {
            $query = "DELETE access_token, refresh_token FROM RegisteredApps WHERE client_id=:client_id";
            $statement = $this->conn->prepare($query);
            $statement->execute(
                array(":client_id" => $client_id)
            );
        } catch(PDOException $exception){
            echo $exception->getMessage();
        }
    }

    // Check if client is valid
    private function getClient($client_id){
        try {
            $query = "SELECT * FROM RegisteredApps WHERE client_id=:client_id";
            $statement = $this->conn->prepare($query);
            $statement->execute(
                array(":client_id" => $client_id)
            );
            $total_result = $statement->rowCount();
            return $total_result;

        } catch(PDOException $exception){
            echo $exception->getMessage();
        }
    }

    public function getClientToken($client_id){
        try {
            $query = "SELECT access_token, refresh_token FROM RegisteredApps WHERE client_id=:client_id";
            $statement = $this->conn->prepare($query);
            $statement->execute(
                array(":client_id" => $client_id)
            );
            $result = $statement->fetchAll(PDO::FETCH_ASSOC);
            return $result;

        } catch(PDOException $exception){
            echo $exception->getMessage();
        }
    }

    public function getAccessToken(){
        // FUnction to check if token passed is same as that in database given to client --delete
        // Function to return access token which will used to check the if access token is valid
        // returns access_token
        try {
            // $query = "SELECT access_token FROM RegisteredApps WHERE client_id=:client_id AND client_secret=:client_secret";
            $query = "SELECT access_token,token_created_at FROM RegisteredApps";
            $statement = $this->conn->prepare($query);
            $statement->execute();
            $result = $statement->fetchAll(PDO::FETCH_ASSOC);
            return $result;

        } catch(PDOException $exception){
            echo $exception->getMessage();
        }
    }

    public function getTokenExpiry($access_token){
        try {
            // $query = "SELECT access_token FROM RegisteredApps WHERE client_id=:client_id AND client_secret=:client_secret";
            $query = "SELECT token_created_at, expires FROM RegisteredApps WHERE access_token=:access_token";
            $statement = $this->conn->prepare($query);
            $statement->execute(array(":access_token" => $access_token));
            // $result = $statement->fetchAll(PDO::FETCH_ASSOC);
            $result = $statement->fetchAll();
            forEach($result as $token_result){
                $token_created_at = $token_result['token_created_at'];
                $token_expires = $token_result['expires'];
                return array($token_created_at,$token_expires);
            }

        } catch(PDOException $exception){
            echo $exception->getMessage();
        }
    }

    public function deleteAccessToken($access_token){
        try {
            $query = "UPDATE RegisteredApps SET access_token=NULL WHERE access_token=:access_token";
            $statement = $this->conn->prepare($query);
            $statement->execute(
                array(
                    ":access_token" => $access_token
                )
            );
        } catch(PDOException $exception){
            echo $exception->getMessage();
        }
    }

    // Get the clients and use it to associate with data
    public function getClientByToken($access_token){
        try{
            $query = "SELECT client_id FROM RegisteredApps WHERE access_token=:access_token";
            $statement = $this->conn->prepare($query);
            $statement->execute(array(":access_token" => $access_token));
            $result = $statement->fetchAll(PDO::FETCH_ASSOC);
            foreach ($result as $client) {
                return $client['client_id'];
            }
            return $result;
        } catch(PDOException $e){
            echo $e->getMessage();
        }
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Pbrobit</title>
	<link rel="stylesheet" type="text/css" href="../styles/styles.css">
	<script type="text/javascript" src="../js/main.js" defer></script>
</head>
<body class="page-body">
			<main>
				<nav>
					<div class="nav">
						<div class="resp_nav">
							<div class="logo">Pbrobit</div>
							<div class="menu">
								<input type="button" value="Menu" class="menu_btn">
								</div>
						</div>
					<div class="nav_links">
						<ul>
							<li>Home</li>
							<li>Services</li>
							<li>Operations</li>
							<li>Project</li>
							<li>Gallery</li>
							<li>Stories</li>
							<li>Contact</li>
							<li>About Us</li>
						</ul>
					</div>
					</div>
				</nav>
				<section>
					<div class="hero">
						<div id="hero-message">
							<span id="hero-text">
								Welcome to Pbrobit.
							<br>The best payment system for your third party Services
							</span>
						</div>
					</div>
				</section>
			</main>
</body>
</html>
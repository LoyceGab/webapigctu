function $(value){
	return document.querySelector(value);
};

var a = $(".next");
if(a == null){
	delete a;
}else{
	a.addEventListener("click",next);
}

var start_index = 0;
var end_index = 3;
var current = $(".carousel_content");
var tot = 400;
var tos;


function next(){
	if(tot == 3200 || tot == 2000){
		tot = 0;
		tos = 0;
		current.style.transform = `translateX(${tot}px)`;
	}
	current.style.transform = `translateX(-${tot}px)`;
	tos=tot;
	tot+=400;
};


var is_clicked = false;

$(".menu_btn").addEventListener("click",openMenu);

function openMenu(){

	if(window.innerWidth < 1120){
		

		if(is_clicked === true){
			$(".nav_links").style.display = "block";
			$(".nav_links").style.animation = "movein .5s ease";
			$(".page-body").style.position = "fixed";
			is_clicked = false;
		}
		else{
			$(".nav_links").style.animation = "moveout 15s ease 2s";
			$(".nav_links").style.display = "";
			$(".page-body").style.position = "";
			is_clicked = true;
		};
		console.log(is_clicked);
	};

	if(window.innerWidth > 1119){
		delete is_clicked;
	}
	
};

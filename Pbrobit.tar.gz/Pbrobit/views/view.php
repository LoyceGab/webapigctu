<?php
class View{
    private $view;
    private $data;

    public function __construct()
    {
    }

    public static function view($view,$data){
        // $this->view = $view;
        if(!isset($data)){
            $data = "";
        }
        include ($view);
        return $data;
    }

    public static function exists(){
        echo "Prog";
    }

}


?>
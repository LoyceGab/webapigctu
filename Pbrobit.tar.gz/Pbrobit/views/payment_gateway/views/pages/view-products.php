<?php
session_start();
$_SESSION["admin"] = "Dev";
if(isset($_SESSION["admin"])){
    require_once("../../../../DBHelper/dbhelper.php");
    require_once("../../../../config/Connection.php");

    $username = $_SESSION["admin"];

    $conn = new Connection();
    $conn = $conn->connects();

    $dbhelper = new DBHelper($conn);    
    $query = "SELECT * FROM Products";
    $result = $dbhelper->query($query,null,true);
}
else{
    header("Location: login.php");
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pbrobit | View Products</title>
    <link rel="stylesheet" type="text/css" href="../css/gateway.css">
</head>
<body>
    <nav class="" id="nav">
        <div class="nav-toggle">
            <a href="" id="logo">Pbrobit</a>
            <input type="button" value="☔" name="toggleButton" id="toggleButton">
        </div>
        <div class="nav-drop">
            <ul>
                <li id="nav-drop-profile"><img src="../images/accountsetting.png" alt="" height="30px" width="30px">
                    <div class="org-account-menu">
                        <ul>
                        <li><a href="../../scripts/org-logout.php">Logout</a></li>
                        </ul>
                    </div>
                </li>
            </ul>
        </div>
    </nav>
    <section class="org-body">
    <?php include("commons/sidebar.php"); ?>
        <main>
            <section class="content">
                <div class="content-body">
                    <header>
                        <h1 id="content-body-title">Products</h1>
                    </header>
                    <div class="content-body-contents">
                       <table id="view-event">
                           <tr id="view-event-head">
                               <th>Name of Item</th>
                               <th>Price</th>
                               <th>Image</th>
                           </tr>

                           <?php 
                            if(empty($result)){
                                echo "<tr><td colspan='3'>No Product Added Yet</td></tr>";  
                            }else{
                                forEach($result as $data){
                                    $name = $data["name"];
                                    $price = $data["price"];
                                    $image = $data["image"];

                            echo "<tr>
                            <td>$name</td>
                            <td>$price</td>
                            <td><img src='../../../upload/$image' height='40px' width='40px'></td>
                        </tr>";
                           }
                           };
                            ?>
                           
                       </table>
                    </div>
                </div>
            </section>
        </main>
    </section>
</body>
</html>
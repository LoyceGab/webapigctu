<?php
// session_start();
// $_SESSION["admin"] = "Dev";
// if(isset($_SESSION["admin"])){
//     require_once("../../../../DBHelper/dbhelper.php");
//     require_once("../../../../config/Connection.php");

//     $username = $_SESSION["admin"];

//     $conn = new Connection();
//     $conn = $conn->connects();

//     $dbhelper = new DBHelper($conn);    
//     $query = "SELECT * FROM Products";
//     $result = $dbhelper->query($query,null,true);
// }
// else{
//     header("Location: login.php");
// }

session_start();
if(!isset($_SESSION["admin"])){
    header("Location: login.php");
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pbrobit | Create Product</title>
    <link rel="stylesheet" type="text/css" href="../css/gateway.css">
</head>
<body>
    <nav class="" id="nav">
        <div class="nav-toggle">
            <a href="" id="logo">Pbrobit</a>
            <input type="button" value="☔" name="toggleButton" id="toggleButton">
        </div>
        <div class="nav-drop">
            <ul>
                <li id="nav-drop-profile"><img src="../images/accountsetting.png" alt="" height="30px" width="30px">
                    <div class="org-account-menu">
                        <ul>
                        <li><a href="../../scripts/org-logout.php">Logout</a></li>
                        </ul>
                    </div>
                </li>
            </ul>
        </div>
    </nav>
    <section class="org-body">
    <?php include("commons/sidebar.php"); ?>
        <main>
            <section class="content">
            <div class="content-body">
                    <header>
                        <h1 id="content-body-title">Create Product</h1>
                    </header>
                    <div class="content-body-contents">
                        <form action="./scripts/create-product" method="POST" enctype="multipart/form-data">
                            <label for="create_product_name" id="add-event-label">Name</label> <br>
                            <input type="text" name="create_product_name" placeholder="Name of Product" id="add-event-title" required>
                            <br>
                            <label for="create_product_image" id="add-event-label">Image</label> <br>
                            <input type="file" name="create_product_image[]" placeholder="Image of Product" id="add-event-image" required>
                            <br>
                            <label for="create_product_price" id="add-event-label">Price</label><br>
                            <input type="number" name="create_product_price" placeholder="GHC 0.00" id="add-event-amount" min="0" value="0" required>
                            <br>
                            <label for="create_product_category" id="add-event-label">Category</label> <br>
                            <select name="create_product_category" id="add-event-price" required>
                                <option disabled selected>Select Category</option>
                                <option value="Book">Book</option>
                                <option value="Attire">Attire</option>
                            </select>
                            <br>
                            <input type="submit" value="Create Product" name="create_product_submit" id="add-event-submit">
                        </form>
                    </div>
                </div>
            </section>
        </main>
    </section>
</body>
</html>
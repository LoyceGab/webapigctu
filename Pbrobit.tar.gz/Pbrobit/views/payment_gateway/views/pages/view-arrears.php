<?php 
$_SESSION["admin"] = "Dev";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pbrobit | View Arrears</title>
    <link rel="stylesheet" type="text/css" href="../css/gateway.css">
</head>
<body>
    <nav class="" id="nav">
        <div class="nav-toggle">
            <a href="" id="logo">Pbrobit</a>
            <input type="button" value="☔" name="toggleButton" id="toggleButton">
        </div>
        <div class="nav-drop">
            <ul>
                <li id="nav-drop-profile"><img src="../images/accountsetting.png" alt="" height="30px" width="30px">
                    <div class="org-account-menu">
                        <ul>
                        <li><a href="../../scripts/org-logout.php">Logout</a></li>
                        </ul>
                    </div>
                </li>
            </ul>
        </div>
    </nav>
    <section class="org-body">
        <aside>
            <section>
                <div class="org-sidebar">
                    <header>
                        <h2 id="org-sidebar-header">Dashboard</h2>
                    </header>
                    <ul>
                        <li><a href="view-arrears.php">Arrears</a></li>
                        <li><a href="view-payments.php">Payments</a></li>
                        <li><a href="view-transactions.php">Transactions</a></li>
                        <li><a href="view-refunds.php">Refunds</a></li>
                        <hr>
                        <li><a href="create-product.php">Create Product</a></li>
                        <li><a href="view-products.php">View Products</a></li>
                        <li><a href="view-orders.php">View Orders</a></li>
                        <hr>
                        <li><a href="create-arrear.php">Create An Arrear</a></li>
                    </ul>
                </div>
            </section>
    </aside>
        <main>
            <section class="content">
                <div class="content-body">
                    <header>
                        <h1 id="content-body-title">Arrears</h1>
                    </header>
                    <div class="content-body-contents">
                       <table id="view-event">
                           <tr id="view-event-head">
                               <th>Reference</th>
                               <th>Student ID</th>
                               <th>Student Name</th>
                               <th>Student Class</th>
                               <th>Programme</th>
                               <th>Fees Owed</th>
                           </tr>

                       </table>
                    </div>
                </div>
            </section>
        </main>
    </section>

    <!-- Scipts -->
    <script>
        fetch("http://pbrobit.com/oauth2/v2/token",{
                    method: "POST",
                    headers: {
                        "Authorization" : "Basic UGJyb2JpdDpwYnJvYml0"
                    }
                }).then(res => res.json()).then(token => {

        fetch("http://pbrobit.com/api/v1/arrears",{
            method: "GET",
            headers: {
                "Content-Type" : "application/json",
                "Authorization": `Bearer ${token.access_token}`
            },
            redirect: 'follow',
            mode: "cors"
            
        })
        .then((res) => res.json()).then((data) => { 
            let arrears_data = document.getElementById("view-event");
            if(data.length == 0){
                arrears_data.innerHTML += "<tr><td colspan='4'>No Arrears Created Yet</td></tr>";
            }
            data.forEach(arrears => {
                arrears_data.innerHTML += `<tr>
                            <td>${arrears.reference}</td>
                            <td>${arrears.student_id}</td>
                            <td>${arrears.student_name}</td>
                            <td>${arrears.student_class}</td>
                            <td>${arrears.student_course}</td>
                            <td>Ghc ${arrears.fees_owed}</td>
                    </tr>`;
            });
        })})
    </script>


</body>
</html>
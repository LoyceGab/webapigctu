<?php echo '

<aside>
            <section>
                <div class="org-sidebar">
                    <header>
                        <h2 id="org-sidebar-header">Dashboard</h2>
                    </header>
                    <ul>
                        <li><a href="view-arrears.php">Arrears</a></li>
                        <li><a href="view-payments.php">Payments</a></li>
                        <li><a href="view-transactions.php">Transactions</a></li>
                        <li><a href="view-refunds.php">Refunds</a></li>
                        <hr>
                        <li><a href="create-product.php">Create Product</a></li>
                        <li><a href="view-products.php">View Products</a></li>
                        <li><a href="view-orders.php">View Orders</a></li>
                        <hr>
                        <li><a href="create-arrear.php">Create An Arrear</a></li>
                    </ul>
                </div>
            </section>
    </aside>';

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pbrobit | Create An Arrear</title>
    <link rel="stylesheet" type="text/css" href="../css/gateway.css">
</head>
<body>
    <nav class="" id="nav">
        <div class="nav-toggle">
            <a href="" id="logo">Pbrobit</a>
            <input type="button"    value="☔" name="toggleButton" id="toggleButton">
        </div>
        <div class="nav-drop">
            <ul>
                <li id="nav-drop-profile"><img src="../images/accountsetting.png" alt="" height="30px" width="30px">
                    <div class="org-account-menu">
                        <ul>
                        <li><a href="../../scripts/org-logout.php">Logout</a></li>
                        </ul>
                    </div>
                </li>
            </ul>
        </div>
    </nav>
    <section class="org-body">
        <aside>
            <section>
                <div class="org-sidebar">
                    <header>
                        <h2 id="org-sidebar-header">Dashboard</h2>
                    </header>
                    <ul>
                        <li><a href="view-arrears.php">Arrears</a></li>
                        <li><a href="view-payments.php">Payments</a></li>
                        <li><a href="view-transactions.php">Transactions</a></li>
                        <li><a href="view-refunds.php">Refunds</a></li>
                        <hr>
                        <li><a href="create-product.php">Create Product</a></li>
                        <li><a href="view-products.php">View Products</a></li>
                        <li><a href="view-orders.php">View Orders</a></li>
                        <hr>
                        <li><a href="create-arrear.php">Create An Arrear</a></li>
                    </ul>
                </div>
            </section>
        </aside>
        <main>
            <section class="content">
            <div class="content-body">
                    <header>
                        <h1 id="content-body-title">Create An Arrear</h1>
                    </header>
                    <div class="content-body-contents">
                        <form enctype="application/x-www-form-urlencoded" id="create_arrear_form">
                            <label for="create_arrear_name" id="add-event-label">Student's Name</label> <br>
                            <input type="text" name="create_arrear_name" placeholder="Name of Student" id="create-arrear-name">
                            <br>
                            <label for="create_arrear_id" id="add-event-label">Student's ID</label> <br>
                            <input type="text" name="create_arrear_id" placeholder="Student ID" id="create-arrear-id" required>
                            <br>
                            <label for="create_arrear_class" id="add-event-label">Student's Class</label> <br>
                            <input type="text" name="create_arrear_class" placeholder="Class of Student" id="create-arrear-class">
                            <br>
                            <label for="create_arrear_course" id="add-event-label">Programme</label> <br>
                            <input type="text" name="create_arrear_course" placeholder="Programme Student is reading" id="create-arrear-course">
                            <br>
                            <label for="create_arrear_fees" id="add-event-label">Fees Owed</label><br>
                            <input type="number" name="create_arrear_fees" placeholder="GHC 0.00" id="create-arrear-fees" min="0" value="0">
                            <br>
                            <input type="submit" value="Create Arrear" name="create_arrear_submit" id="add-event-submit">
                        </form>
                    </div>
                </div>
            </section>
        </main>
    </section>



    <!-- Scipts -->
    <script>

        // Get ID
            function getId(id){
                var result = document.getElementById(id);
                return result;
            }

            function getValue(key){
                return key.value;
            }


        let create_arrear_form = document.getElementById("create_arrear_form");
        create_arrear_form.addEventListener("submit",function(e){
            e.preventDefault();

            

            var student_id = getId("create-arrear-id");
            var student_name = getId("create-arrear-name");
            var student_class = getId("create-arrear-class");
            var student_course = getId("create-arrear-course");
            var fees_owed = getId("create-arrear-fees");

            const arrearData = {
                "student_id": getValue(student_id),
                "student_name": getValue(student_name),
                "student_class": getValue(student_class),
                "student_course": getValue(student_course),
                "fees_owed": getValue(fees_owed)
            };


        fetch("http://pbrobit.com/oauth2/v2/token",{
                    method: "POST",
                    headers: {
                        "Authorization" : "Basic UGJyb2JpdDpwYnJvYml0"
                    }
                }).then(res => res.json()).then(token => {

        fetch("http://pbrobit.com/api/v1/arrears/",{
            method: "POST",
            body: JSON.stringify(arrearData),
            headers: {
                "Content-Type" : "application/json",
                "Authorization": `Bearer ${token.access_token}`
            },
            redirect: 'follow',
            mode: "cors"
            
        })
        .then((res) => res.text()).then((data) => { 
            alert("Successfully");
        })
    })
})
    </script>
</body>
</html>
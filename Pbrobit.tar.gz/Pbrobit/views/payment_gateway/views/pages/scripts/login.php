<?php
session_start();
if(isset($_POST["user_login"])){
    require_once("../../../../../DBHelper/dbhelper.php");
    require("../../../../../config/Connection.php");

    $username = $_POST["username"];
    $password = $_POST["password"];

    $dbconn = new Connection();
    $conn = $dbconn->connects();


    $dbhelper = new DBHelper($conn);
    $query = "SELECT password FROM Admins WHERE email = :username";
    $execute_options = array(":username" => $username);
    $result = $dbhelper->query($query,$execute_options,true);
    forEach($result as $data){
        $hashed_password = $data["password"];
    if(password_verify($password,$hashed_password)){
        $_SESSION["admin"] = "Pbrobit_Admin";
        header("Location: http://pbrobit.com/views/payment_gateway/views/pages/view-transactions");
    }else{
        header("Location: ../view-arrears.php");
    }
}
}else{
    header("Location: ../login.php");
}
?>
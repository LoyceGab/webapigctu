<?php
session_start();
if(isset($_SESSION["admin"])){
if(isset($_POST["transaction_refund"])){
    require_once("../../../../../DBHelper/dbhelper.php");
    require("../../../../../config/Connection.php");
    require("../../../../../utils/referenceGenerator.php");
    require("../../../../../models/transactions/transaction.php");

    $referenceGenerator = new ReferenceGenerator();

    $reference = $referenceGenerator->generate();
    $transaction_reference = $_POST["transaction_reference"];
    $refund_amount = $_POST["refund_amount"];
    $currency = "Ghc";
    $date_created = time();

    $dbconn = new Connection();
    $conn = $dbconn->connects();

    $dbhelper = new DBHelper($conn);
    $query = "INSERT INTO Refunds(reference,transaction_reference,amount,currency,date_created)
    VALUES('$reference','$transaction_reference','$refund_amount','$currency','$date_created')";
    $dbhelper->query($query);
    $transactionModel = new TransactionModel($conn);
    $transactionModel->addRefundStatus(array("reference" => $transaction_reference, "refund_status" => "refunded"));
    header("Location: ../view-transactions.php");
}
}else{
    header("Location: ../login.php");
}
?>  

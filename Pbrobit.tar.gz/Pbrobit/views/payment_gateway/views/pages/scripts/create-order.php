<?php
session_start();
if(isset($_SESSION["admin"])){
    require_once("../../../../../DBHelper/dbhelper.php");
    require("../../../../../config/Connection.php");
    require("../../../../../utils/referenceGenerator.php");
    // require("../../../../../models/transactions/transaction.php");

    $referenceGenerator = new ReferenceGenerator();

    $reference = $referenceGenerator->generate();
    
    $customer_cart_id = $_GET["customer_id"];
    
    $currency = "Ghc";
    $date_created = time();

    $dbconn = new Connection();
    $conn = $dbconn->connects();

    $dbhelper = new DBHelper($conn);

    //  Select Data from Cart
    $cart_query = "SELECT * FROM Cart WHERE customer_id=:customer_cart_id";
    $cart_execute_query = array(":customer_cart_id" => $customer_cart_id);
    $cart_results = $dbhelper->query($query,$cart_execute_query,true);

    forEach($cart_results as $cart_result){
            $product_name = $cart_result["product_name"];
            $price = $cart_result["price"];
    }

    $query = "INSERT INTO Refunds(reference,transaction_reference,amount,currency,date_created)
    VALUES('$reference','$transaction_reference','$refund_amount','$currency','$date_created')";
    $dbhelper->query($query);
    $transactionModel = new TransactionModel($conn);
    $transactionModel->addRefundStatus(array("reference" => $transaction_reference, "refund_status" => "refunded"));
    header("Location: ../view-transactions.php");
}else{
    header("Location: ../login.php");
}
?>  

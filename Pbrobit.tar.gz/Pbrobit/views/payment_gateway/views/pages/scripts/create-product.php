<?php
session_start();
if(isset($_SESSION["admin"])){
if(isset($_POST["create_product_submit"])){
    require_once("../../../../../DBHelper/dbhelper.php");
    require("../../../../../config/Connection.php");
    $name = $_POST["create_product_name"];
    $price = $_POST["create_product_price"];
    $category = $_POST["create_product_category"];

    $dbconn = new Connection();
    $conn = $dbconn->connects();


    $output_dir = "../../../../upload/";
	$RandomNum   = time();
	$ImageName      = str_replace(' ','-',strtolower($_FILES['create_product_image']['name'][0]));
	$ImageType      = $_FILES['create_product_image']['type'][0];
 
	$ImageExt = substr($ImageName, strrpos($ImageName, '.'));
	$ImageExt       = str_replace('.','',$ImageExt);
	$ImageName      = preg_replace("/\.[^.\s]{3,4}$/", "", $ImageName);
	$image = $ImageName.'-'.$RandomNum.'.'.$ImageExt;
    $ret[$image]= $output_dir.$image;
	
	
	if (!file_exists($output_dir))
	{
		@mkdir($output_dir, 0777);
	}               
	move_uploaded_file($_FILES["create_product_image"]["tmp_name"][0],$output_dir."/".$image );

    $dbhelper = new DBHelper($conn);
    $query = "INSERT INTO Products(name,price,image,category)
    VALUES('$name','$price','$image','$category')";
    $dbhelper->query($query);
    header("Location: ../create-product.php");
}
}else{
    header("Location: ../login.php");
}
?>  

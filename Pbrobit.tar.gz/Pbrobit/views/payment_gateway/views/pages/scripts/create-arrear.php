<?php
session_start();
if(isset($_SESSION["admin"])){
if(isset($_POST["create_arrear_submit"])){

    require_once("../../../../../DBHelper/dbhelper.php");
    require("../../../../../config/Connection.php");
    require("../../../../../utils/referenceGenerator.php");

    $referenceGenerator = new ReferenceGenerator();

    $reference = $referenceGenerator->generate();
    $name = $_POST["create_arrear_name"];
    $id = $_POST["create_arrear_id"];
    $class = $_POST["create_arrear_class"];
    $course = $_POST["create_arrear_course"];
    $fees = $_POST["create_arrear_fees"];
    $date_created = time();

    $dbconn = new Connection();
    $conn = $dbconn->connects();

    $dbhelper = new DBHelper($conn);
    $query = "INSERT INTO Arrears(reference,student_id,student_name,student_class,student_course,fees_owed,date_created)
    VALUES('$reference','$id','$name','$class','$course','$fees','$date_created')";
    $dbhelper->query($query);
    header("Location: ../create-arrear.php");
}
}else{
    header("Location: ../login.php");
}
?>  

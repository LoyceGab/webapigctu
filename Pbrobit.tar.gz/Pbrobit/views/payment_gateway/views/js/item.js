document.addEventListener("DOMContentLoaded", function(){

    var item_paybox_button = getId("paybox-card-details");
    var item_amount = localStorage.getItem("checkout_amount");
    item_paybox_button.value = `Pay Ghc ${item_amount}`;

// Item Payment
var item_submit = getId("item-paybox");
item_submit.onsubmit = function(e){
    e.preventDefault();
    order();
};
})

// Get ID
function getId(id){
    var result = document.getElementById(id);
    return result;
}

function getValue(key){
    return key.value;
}

function jsons(data){
    return JSON.stringify(data);
}

function texts(json){
    return JSON.parse(json);
}

const getQueryParams = ( params, url ) => {
    let href = url;
    // this is an expression to get query strings
    let regexp = new RegExp( '[?&]' + params + '=([^&#]*)', 'i' );
    let qString = regexp.exec(href);
    return qString ? qString[1] : null;
  };



function order(){
    var payer = getId("paybox-payer");
    var email = getId("paybox-email");
    var phone_number = getId("paybox-phonenumber");
    var card_number = getId("paybox-card-number");
    var card_expiry_month= getId("paybox-card-expiry-month");
    var card_expiry_year = getId("paybox-card-expiry-year");
    var card_cvv = getId("paybox-card-cvv");
    var cart_amount = localStorage.getItem("checkout_amount")
    
    var customer_checkout_id = localStorage.getItem("customer_id");

    

    var payment_details = {
        "depositor_name" : `${getValue(payer)}`,
        "depositor_email" : `${getValue(email)}`,
        "phone_number" : getValue(phone_number),
        "card_number" : getValue(card_number),
        "card_expiry_month" : getValue(card_expiry_month),
        "card_expiry_year" : getValue(card_expiry_year),
        "card_cvv" : getValue(card_cvv),
        "amount" : cart_amount,
        "payment_method" : "card"
    }

    fetch("http://pbrobit.com/oauth2/v2/token",{
                method: "POST",
                headers: {
                    "Authorization" : "Basic UGJyb2JpdDpwYnJvYml0"
                }
            }).then(res => res.json()).then(token => {

    fetch("http://pbrobit.com/api/v1/payment/",{
        method: "POST",
        body: jsons(payment_details),
        headers: {
            "Content-Type" : "application/json",
            "Authorization": `Bearer ${token.access_token}`
        },
        redirect: 'follow',
        mode: "cors"
        
    })
    .then((res) => res.json()).then((data) => { 
        // 4242424242424242
        
    //     if(data.payment_status.status === undefined){
    //     console.log(JSON.stringify({"message":"Need to insert data"}))
    // }
    // else 
    if(data.payment_status.status == "Approved"){
        window.location=`http://localhost/project/Pbrobit/views/school_website/views/pages/confirmed.php?id=${customer_checkout_id}`;
    }
    else{
        window.location="http://localhost/project/Pbrobit/views/school_website/views/pages/rejected.html";
    }

    console.log(data);
})



})

};
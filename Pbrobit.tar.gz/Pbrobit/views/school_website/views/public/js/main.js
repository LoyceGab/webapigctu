function getId(ref){
    var refId =  document.getElementById(ref);
    if(refId == null || refId == undefined){
        let result = refId = "";
        return result;
    }
    else{
        return refId;
    }
}


function getValue(key){
    return key.value;
}

const getQueryParams = ( params, url ) => {
    let href = url;
    
    // expression to get query strings
    let regexp = new RegExp( '[?&]' + params + '=([^&#]*)', 'i' );
    let qString = regexp.exec(href);
    return qString ? qString[1] : null;
  };

document.addEventListener('DOMContentLoaded',function(){

var path = document.location.pathname.split("/");
var checkout_btn = getId("checkout-btn");
var checkout_customerid =getId("customer_id");
var checkout_amount = getId("checkout-amount");
checkout_btn.addEventListener("click", () => {
    localStorage.setItem("customer_id", getValue(checkout_customerid));
    localStorage.setItem("checkout_amount",getValue(checkout_amount));
    window.location = `http://pbrobit.com/views/payment_gateway/views/pages/item-paybox.html`;
    // window.location = `http://pbrobit.com/views/payment_gateway/views/pages/item-paybox.html?id=${getValue(checkout_customerid)}`;
});



document.addEventListener('scroll',function(){
    var nav = getId('nav');
    var nav_home = getId('nav-home');

    console.log(path[5]);

    nav.style.visibility = "visible";
    nav.style.backgroundColor = `#FFFFFF`;
    nav.style.color = `#FFFFFF`;
    nav.style.boxShadow = "0px 1px 10px 9px rgba(0,0,10,.03)";

    if(path[5] == "index" || path[5] == ""){
        if(scrollY >= 605){
            nav_home.style.visibility = "visible";
            nav_home.style.backgroundColor = `#FFFFFF`;
            nav_home.style.color = `#FFFFFF`;
            nav_home.style.boxShadow = "0px 1px 10px 9px rgba(0,0,10,.03)";
            nav.style.visibility = "visible";
            nav.style.backgroundColor = `#FFFFFF`;
            nav.style.color = `#FFFFFF`;
            nav.style.boxShadow = "0px 1px 10px 9px rgba(0,0,10,.03)";
        };
        if(scrollY > 30 && scrollY < 605){
            nav_home.style.visibility = "hidden";
            nav_home.style.color = `#FFFFFF`;
        }  
        if(scrollY >= 0 && scrollY < 30){
            nav_home.style.backgroundColor="inherit";
            nav_home.style.visibility = "visible";
            nav_home.style.boxShadow = "0px 0px 0px 0px rgba(0,0,10,.03)";
        }
    }
    

})

});
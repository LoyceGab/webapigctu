<?php
// if(isset($_COOKIE["Pbrobit_customer_reference"])){

    require_once("../../../../DBHelper/dbhelper.php");
    require("../../../../config/Connection.php");
    require("../../../../utils/referenceGenerator.php");

    $referenceGenerator = new ReferenceGenerator();

    $reference = $referenceGenerator->generateNumbers();
   
    $date_created = time();

    $dbconn = new Connection();
    $conn = $dbconn->connects();

    $dbhelper = new DBHelper($conn);

    $customer_id = $_GET["id"];
    //Select from Cart
    $cart_query = "SELECT product_name, price,customer_id FROM Cart WHERE customer_id = :customer_id";
    $cart_execute_option = array(":customer_id" => $customer_id);
    $cart_results = $dbhelper->query($cart_query,$cart_execute_option,true);

    
    forEach($cart_results as $cart_result){
        $product_name = $cart_result["product_name"];
        $price = $cart_result["price"];
        $cart_customer_id = $cart_result["customer_id"];

        // Orders query
        $order_query = "INSERT INTO Orders(order_id,product_name,price,receiver,customer_id)
            VALUES('$reference','$product_name','$price',NULL,'$cart_customer_id')";
        $dbhelper->query($order_query);

        header("Location: http://pbrobit.com/views/school_website/views/pages/index");
    }
?>  

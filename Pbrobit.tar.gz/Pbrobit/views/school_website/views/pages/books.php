<?php
if(!isset($_COOKIE["Pbrobit_customer_reference"])){

    require_once("../../../../utils/referenceGenerator.php");
    
    $referenceGenerator = new ReferenceGenerator();
    $reference = $referenceGenerator->generate();
    setCookie("Pbrobit_customer_reference",$reference,time() + (10 * 365 * 24 * 60 * 60),"/");

}else{
    $customer_id = $_COOKIE["Pbrobit_customer_reference"];
};
    require_once("../../../../DBHelper/dbhelper.php");
    require_once("../../../../config/Connection.php");


    $conn = new Connection();
    $conn = $conn->connects();

    $dbhelper = new DBHelper($conn);    

    // Books Result
    $query = "SELECT * FROM Products WHERE category=:category";
    $execute_options = array(":category" => "Book");
    $book_result = $dbhelper->query($query,$execute_options,true);


require("commons/headers.php");
generateHeader("All Books");

?>
    <main>
        <section class="all-events-container">
            <div class="all-events">
                <div class="all-events-header">
                    <header>
                        <h1 id="events-title">Books</h1>
                    </header>
                </div>
                <div class="all-events-footer">
                    
                    <?php 
                    if(empty($book_result)){
                        echo "<h2 id='no-data'> No Books Available</h2>";
                    }else{
                    forEach($book_result as $data){
                        $id = $data["id"];
                        $product_name = $data["name"];
                        $image = $data["image"];
                        $price = $data["price"];
                        echo '

                    <div id="events-card">
                        <div class="events-card-header">
                            <img src="../../../upload/'.$image.'" alt="Event Poster" id="events-card-poster">
                        </div>
                        <div class="events-card-footer">
                            <p id="events-card-title">'.$product_name.'</p>
                            <p id="events-card-date">Ghc '.$price.'</p>
                            <div class="events-card-footer-book">
                            <form action="scripts/add_to_cart" method="POST" enctype="multipart/form-data">
                            <input type="hidden" name="customer_id" value="'.$customer_id.'">
                            <input type="hidden" name="product_name" value="'.$product_name.'">
                            <input type="hidden" name="image" value="'.$image.'">
                            <input type="hidden" name="price" value="'.$price.'">
                                <input type="submit" value="Add to Cart" id="events-card-footer-book-btn" name="product_add_to_cart">
                            </form>
                            </div>
                        </div>
                    </div>';
                    }
                };

                if(sizeOf($book_result) > 10){
                 echo "   
                </div>
                <div class='all-events-more'>
                    <a href='event.php?limit=$limit+= 10' id='all-events-loadmore'>Load More ⇣</a>
                </div>";
                };
                ?>
            </div>
        </section>
    </main>
    </body>
    </html>
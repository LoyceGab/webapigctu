<?php
if(!isset($_COOKIE["Pbrobit_customer_reference"])){

    require_once("../../../../utils/referenceGenerator.php");
    
    $referenceGenerator = new ReferenceGenerator();
    $reference = $referenceGenerator->generate();
    setCookie("Pbrobit_customer_reference",$reference,time() + (10 * 365 * 24 * 60 * 60),"/");

}else{
    $customer_id = $_COOKIE["Pbrobit_customer_reference"];
};

    require_once("../../../../DBHelper/dbhelper.php");
    require_once("../../../../config/Connection.php");
    

    $conn = new Connection();
    $conn = $conn->connects();

    $dbhelper = new DBHelper($conn);    
    
    $query = "SELECT * FROM Cart WHERE customer_id=:customer_id";
    $execute_options = array(":customer_id" => $customer_id);
    $results = $dbhelper->query($query,$execute_options,true);

    require("commons/headers.php");
    generateHeader("Cart");

?>
    <main>
        <section class="cart">
            <div class="cart_header">
                <header>
                    <h1>Cart</h1>
                </header>
            </div>

            <!-- Items and Checkout -->
            <div class="cart_footer">
                <div class="cart_items">

                <?php 

                $total_cart_amount = 0;
                $total_cart_product = sizeOf($results);
                if(sizeOf($results) == 0){
                    echo "<h1>No item added to Cart Yet</h1>";
                }else{
                
                forEach($results as $result){
                    $product_name = $result['product_name'];
                    $price = $result['price'];
                    $image = $result['image'];
                    $total_cart_amount += $price;

                    echo '
                    <div class="cart_item">
                        <div class="cart_item_image">
                            <img src="../../../upload/'.$image.'" alt="" height="100%" width="100%">
                        </div>
                        <div class="cart_item_brief">
                            <p><b>'.$product_name.'</b></p>
                            <p>Ghc '.$price.'</p>
                            <p>Quantity: 1</p>
                        </div>
                        <div class="cart_item_increment">
                            <div class="cart_item_increment_items">
                                <input type="button" value="-">
                                <input type="button" value="+">
                                <input type="button" value="X">
                            </div>
                        </div>
                    </div>';

                }
            }
                ?>
                    
                </div>
                <div class="cart_checkout">
                    <header>
                        <h3>Summary</h3>
                    </header>
                    <p>
                        <b>Total Items:</b> <?php echo $total_cart_product; ?>
                    </p>
                    <p>
                        <b>Total Amount:</b> Ghc <?php echo $total_cart_amount; ?>
                    </p>
                    <input type="hidden" id="customer_id" value="<?php echo $customer_id; ?>"/>
                    <input type="hidden" id="checkout-amount" value="<?php echo $total_cart_amount; ?>"/>
                    <div>
                        <input type="button" value="Proceed to Checkout" id="checkout-btn">
                    </div>
                </div>
            </div>
        </section>
    </main>
</body>
</html>

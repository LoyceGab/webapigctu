<?php
if(!isset($_COOKIE["Pbrobit_customer_reference"])){

    require_once("../../../../utils/referenceGenerator.php");
    
    $referenceGenerator = new ReferenceGenerator();
    $reference = $referenceGenerator->generate();
    setCookie("Pbrobit_customer_reference",$reference,time() + (10 * 365 * 24 * 60 * 60),"/");

}else{
    $customer_id = $_COOKIE["Pbrobit_customer_reference"];
};

    require_once("../../../../DBHelper/dbhelper.php");
    require_once("../../../../config/Connection.php");
    

    $conn = new Connection();
    $conn = $conn->connects();

    $dbhelper = new DBHelper($conn);    

    // Books Result
    $query = "SELECT * FROM Products WHERE category=:category";
    $execute_options = array(":category" => "Book");
    $book_result = $dbhelper->query($query,$execute_options,true);

    // Attire Result
    $query = "SELECT * FROM Products WHERE category=:category";
    $execute_options = array(":category" => "Attire");
    $attire_result = $dbhelper->query($query,$execute_options,true);

            // require("commons/header.php");
            // generateHeader("Home");
?>
 <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pbrobit - '.$title.'</title>
    <link rel="stylesheet" type="text/css" href="../public/css/styles.css">
    <link rel="stylesheet" type="text/css" href="../public/css/cart.css">
    <script type="text/javascript" src="../public/js/main.js"></script>
</head>
<body>
    <nav class="" id="nav">
        <div class="nav-toggle">
            <a href="" id="logo">
                <img src="../public/images/logo3.png" alt="">
            </a>
            <input type="button" value="☔" name="toggleButton" id="toggleButton">
        </div>
        <div class="nav-drop">
            <ul>
                <li><a href="index.php">Home</a</li>
                <li><a href="books.php">Buy Books</a></li>
                <li><a href="attires.php">Buy Attires</a></li>
                <li><a href="http://pbrobit.com/views/payment_gateway/views/pages/paybox.html">Pay Fees</a></li>
                <li><a href="cart.php">Cart</a></li>
            </ul>
        </div>
    </nav>
<main>
        <section>
            <div class="hero" id="hero">
                <div class="hero-content">
                    <p>Welcome to Pbrobit</p>
                    <header>
                        <h1>Top School for Learning and achieving your dreams</h1>
                    </header>
                    <a href="http://pbrobit.com/views/payment_gateway/views/pages/paybox.html"><input type="button" value="Pay School Fees" id="hero-explore-btn"></a>
                </div>
            </div>
        </section>

                <?php 
                if(sizeOf($book_result) == 0){

                }else{
                    echo '
                    <section>
                    <div class="events">
                        <header>
                            <h1 id="events-title">Books</h1>
                        </header>
                        <div class="events-card-container">';
                forEach($book_result as $data){
                            $id = $data["id"];
                            $product_name = $data["name"];
                            $image = $data["image"];
                            $price = $data["price"];
                        echo '

                    <div id="events-card">
                        <div class="events-card-header">
                            <img src="../../../upload/'.$image.'" alt="Event Poster" id="events-card-poster">
                        </div>
                        <div class="events-card-footer">
                            <p id="events-card-title">'.$product_name.'</p>
                            <p id="events-card-date">Ghc '.$price.'</p>
                            <div class="events-card-footer-book">
                            <form action="scripts/add_to_cart" method="POST" enctype="multipart/form-data">
                            <input type="hidden" name="customer_id" value="'.$customer_id.'">
                            <input type="hidden" name="product_name" value="'.$product_name.'">
                            <input type="hidden" name="image" value="'.$image.'">
                            <input type="hidden" name="price" value="'.$price.'">
                                <input type="submit" value="Add to Cart" id="events-card-footer-book-btn" name="product_add_to_cart">
                            </form>
                            </div>
                        </div>
                    </div>';
                    }

                echo '
                </div>
                        <div class="more">
                            <a href="../Event/event.php">See more...</a>
                        </div>
                </div>
            </section>';
        }

                    ?>                                       

        <!-- Attires -->
        <?php 
                if(sizeOf($attire_result) == 0){

                }else{
                    echo '
                    <section>
                    <div class="events">
                        <header>
                            <h1 id="events-title">School Attires</h1>
                        </header>
                        <div class="events-card-container">';
                        
                        forEach($attire_result as $data){
                            $id = $data["id"];
                            $product_name = $data["name"];
                            $image = $data["image"];
                            $price = $data["price"];
                        echo '

                    <div id="events-card">
                        <div class="events-card-header">
                            <img src="../../../upload/'.$image.'" alt="Event Poster" id="events-card-poster">
                        </div>
                        <div class="events-card-footer">
                            <p id="events-card-title">'.$product_name.'</p>
                            <p id="events-card-date">Ghc '.$price.'</p>
                            <div class="events-card-footer-book">
                            <form action="scripts/add_to_cart" method="POST" enctype="multipart/form-data">
                            <input type="hidden" name="customer_id" value="'.$customer_id.'">
                            <input type="hidden" name="product_name" value="'.$product_name.'">
                            <input type="hidden" name="image" value="'.$image.'">
                            <input type="hidden" name="price" value="'.$price.'">
                                <input type="submit" value="Add to Cart" id="events-card-footer-book-btn" name="product_add_to_cart">
                            </form>
                            </div>
                        </div>
                    </div>';
                    }

                   
                echo '
                </div>
                        <div class="more">
                            <a href="../Event/event.php">See more...</a>
                        </div>
                </div>
            </section>';
        }

                    ?>  

        <!-- Pay Your School Fees -->
        <section>
            <div class="host-event-container" id="host-event-container">
                <div class="host-event">
                    <p>Havent Paid Your School Fees Yet?</p>
                    <p><a href="http://pbrobit.com/views/payment_gateway/views/pages/paybox.html"><input type="button" value="Pay It Here" id="pay-fees-btn"></a></p>
                </div>
            </div>
        </section>
    
          <!-- Newsletter Section-->
          <section>
            <div class="newsletter">
                <div class="newsletter-container">
                    <header>
                        <h1>Subscribe to our Newsletter</h1>
                    </header>
                    <br>
                    <div class="newsletter-subscription">
                        <form method="POST" enctype="multipart/form-data">
                        <input type="email" placeholder="Your Email Address" id="newsletter-subscribe-email"><input type="submit" value="Subscribe" id="newsletter-subscribe-button" name="newsletter-subscribe">
                    </form>
                    </div>
                </div>
            </div>
        </section>
        
    </main>
    <footer>
        <div class="main-footer">
            <div class="main-footer-logo">
                <header>
                    <img src="../public/images/logo3.png" alt="Pbrobit">
                </header>
            </div>
            <div class="main-footer-events">
                <header>
                    <h3>Quick Links</h3>
                </header>
                <div class="main-footer-events-links">
                    <ul>
                        <li>Pay School Fees</li>
                        <li>Buy Books</li>
                        <li>Buy Attires</li>
                    </ul>
                </div>
            </div>
            <div class="main-footer-quick">
                <header>
                    <h3>Support</h3>
                </header>
                <div class="main-footer-quick-links">
                    <ul>
                        <li>FAQs</li>
                    </ul>
                </div>
            </div>
            <div class="main-footer-about">
                <header>
                    <h3>Reach Us</h3>
                </header>
                <div class="main-footer-about-links">
                    <ul>
                        <li>Address:<br> P.O.Box AZ 80, Agbozume-Biakor</li>
                        <li>Tel:<br> <a href="tel:0554513648">0554513648</a></li>
                        <li> Email:<br>
                            <a href="mailto:susuasseymarvelousguy@gmail.com">susuasseymarvelousguy@gmail.com</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="sub-footer">
            <p>Copyright &copy 2021 - Pbrobit</p>
            <div class="sub-footer-social-networks">
                <ul>
                    <li><img src="../public/images/social/facebook.png" alt="" height="25px" width="25px"></li>
                    <li><img src="../public/images/social/twitter.png" alt="" height="25px" width="25px"></li>
                    <li><img src="../public/images/social/instagram2.png" alt="" height="25px" width="25px"></li>
                    <li><img src="../public/images/social/whatsapp2.png" alt="" height="25px" width="25px"></li>
                </ul>
            </div>
        </div>
    </footer>
</body>
</html>
        
<?php
if(!isset($_COOKIE["Pbrobit_customer_reference"])){

    require_once("../../../../utils/referenceGenerator.php");
    
    $referenceGenerator = new ReferenceGenerator();
    $reference = $referenceGenerator->generate();
    setCookie("Pbrobit_customer_reference",$reference,time() + (10 * 365 * 24 * 60 * 60),"/");

}else{
    $customer_id = $_COOKIE["Pbrobit_customer_reference"];
};

if(isset($_POST["product_add_to_cart"])){

    require_once("../../../../../DBHelper/dbhelper.php");
    require("../../../../../config/Connection.php");
    require("../../../../../utils/referenceGenerator.php");

    $product_name = $_POST["product_name"];
    $price = $_POST["price"];
    $image = $_POST["image"];
    $customer_buy_id = $_POST["customer_id"];

    $referer = $_SERVER["HTTP_REFERER"];

    $dbconn = new Connection();
    $conn = $dbconn->connects();

    $dbhelper = new DBHelper($conn);
    $query = "INSERT INTO Cart(customer_id,product_name,price,image)
    VALUES('$customer_buy_id','$product_name','$price','$image')";
    $dbhelper->query($query);
    header("Location: $referer");
}

?>
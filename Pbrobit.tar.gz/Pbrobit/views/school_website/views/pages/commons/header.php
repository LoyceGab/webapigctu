<?php

function generateHeader($title){
    echo '
    <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pbrobit - '.$title.'</title>
    <link rel="stylesheet" type="text/css" href="../public/css/styles.css">
    <script type="text/javascript" src="../public/js/main.js"></script>
</head>
<body>
    <nav class="" id="nav-home">
        <div class="nav-toggle">
            <a href="" id="logo">
                <img src="../public/images/logo3.png" alt="">
            </a>
            <input type="button" value="☔" name="toggleButton" id="toggleButton">
        </div>
        <div class="nav-drop">
            <ul>
                <li><a href="index.php">Home</a</li>
                <li><a href="books.php">Buy Books</a></li>
                <li><a href="attires.php">Buy Attires</a></li>
                <li><a href="http://pbrobit.com/views/payment_gateway/views/pages/paybox.html">Pay Fees</a></li>
                <li><a href="cart.php">Cart</a></li>
            </ul>
        </div>
    </nav>
';
}

?>
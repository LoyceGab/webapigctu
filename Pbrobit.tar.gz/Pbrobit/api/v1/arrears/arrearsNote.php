<?php


// This endpoint makes students or clients to check students' owed school fees

// Get fees oweed by student GET api/v1/arrears/{studentID}
// Get total fees owed by student GET api/v1/arrears/{studentID}/total


// GET api/v1/arrears/{studentID} - returns fees owed by a student

// Parameters
// {
//     reference: ,
//     studentID: ,
//     student_name: ,
//     student_class: ,
//     student_course: ,
//     semester: , // For this, it can be term instead Term {1,2,3}
    
// }

// /createArrears

// Parameters
// {
//     reference: ,
//     studentID: ,
//     student_name: ,
//     student_class: ,
//     student_course: ,
//     fees_owed: ,
    
// }


// /getArrears/{studentID}


// /updateArrears/{studentID}
// Parameters
// {
//     studentID: ,
//     fees_owed: ,
// }


// - You can't delete arrears. Better to update arrears and change owed_fees to {null or 0}

// removed
// {
//     school_fees_paid: ,
//     total_fees_to_pay: ,
//     school_fees_remaining: ,
// }






// PAYMENT
// {
//     student_id,
//     depositor's name
//     depositor's email
//     receipient' name
//     payment_option
//     payment_method,
//     amount,
//     currency,
//     card_number,
//     card_expiry_month
//     card_expiry_year,
//     card_cvv,
//     phone_number
// }


// Returns

// {
//     reference:
//     student_id,
//     depositor's name
//     depositor's email
//     receipient' name
//     payment_option
//     payment_method,
//     amount,
//     currency,
//     card_number,
//     card_expiry_month
//     card_expiry_year,
//     card_cvv,
//     phone_number
//     status,
// }        

?>
<?php 
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
$authorization = apache_request_headers();
if(!isset($authorization['Authorization'])){
    http_response_code(401);
    echo json_encode(array("Error"=>"Authorization Required"));
}
else{

    $authorization_data = explode(" ",$authorization['Authorization']);    

    // Auth check start
    if(sizeof($authorization_data) == 2){
        $authorization_type = $authorization_data[0];
        $authorization_secret = $authorization_data[1];

        if($authorization_type != "Bearer"){
            http_response_code(401);
            echo json_encode(array("Error"=>"Authorization Type - Bearer Token Required"));
        }
        else{
            require("../../../restriction/blacklist.php");

            $includes = array(
                "../../../config/Connection.php",
                "../../../controllers/token/token.php",
                "../../../models/token/token.php",
                "../../../controllers/transaction/transactionController.php",
                "../../../models/transactions/transaction.php",
                "../../../utils/referenceGenerator.php",
                "../../../utils/check.php"
            );
            
            $allowed_includes = array(
                "../../../config/Connection.php",
                "../../../models/token/token.php",
                "../../../controllers/token/token.php",
                "../../../controllers/transaction/transactionController.php",
                "../../../models/transactions/transaction.php",
                "../../../utils/referenceGenerator.php",
                "../../../utils/check.php"
            );
            
            $inc = new Blacklist();
            $inc->check($includes,$allowed_includes);
            
            $conn = new Connection();
            $conn = $conn->connects();

            $token = new TokenController($conn);
            $hasErrors = $token->verifyClient($authorization_secret);

            if($hasErrors['hasError'] == true){
                http_response_code(401);
                echo json_encode(array("Error" => "Access Rejected"));
            }else{
            
            header("Access-Control-Allow-Origin: http://localhost/Pbrobit/api/v1/");
            header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
            header("Access-Control-Max-Age: 6000");
            header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
            http_response_code(200);

            $request_method = $_SERVER["REQUEST_METHOD"];


            $uri = $_SERVER['REQUEST_URI'];
            $url = explode("/",$uri);


            $size_of_url = sizeof($url);

            global $options;

            if($size_of_url == 7){
                $id = $url[6];
                $options = array($id);
            } else if($size_of_url == 8){
                $id = $url[6];
                $target =  $url[7];
                $options = array($id,$target);
            }
                else if($size_of_url == 6){
                    $options = array();
                }


            $allowed_methods = array("GET","POST");

        // Checker instance
        $check = new Check();

        if($request_method == "GET"){
            $transaction = new TransactionController($conn);
            $client_id = $hasErrors['client_id'];
            if(isset($_GET['reference'])){
                $reference = $_GET['reference'];
                $data = array("client_id" => $client_id, "reference" => $reference);
                $transaction->getTransaction($data);
            }else{
                $data = array("client_id" => $client_id);
                $transaction->getTransactions($data);
                }
            
        }
    else if($request_method == "POST"){


    $transaction = new TransactionController($conn);
    $transaction->createTransaction($hasErrors);
        


} else{
    if(!in_array($request_method,$allowed_methods)){
        echo json_encode(array("method"=>"Not Allowed"));
    }
}
            }
        }



    } // Auth check end

    else{
        echo json_encode(array("Error"=>"Authorization Not Accepted"));
    }

}

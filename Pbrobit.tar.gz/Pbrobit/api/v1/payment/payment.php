<?php 
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
$authorization = apache_request_headers();
if(!isset($authorization['Authorization'])){
    http_response_code(401);
    echo json_encode(array("Error"=>"Authorization Required", "Description" => "Authorization Header not Set"));
}
else{

    $authorization_data = explode(" ",$authorization['Authorization']);    

    // Auth check start
    if(sizeof($authorization_data) == 2){
        $authorization_type = $authorization_data[0];
        $authorization_secret = $authorization_data[1];

        if($authorization_type != "Bearer"){
            http_response_code(401);
            echo json_encode(array("Error"=>"Wrong Authorization Type", "Solution" => "Bearer Token Required"));
        }
        else{
            require("../../../restriction/blacklist.php");

            $includes = array(
                "../../../config/Connection.php",
                "../../../controllers/token/token.php",
                "../../../models/token/token.php",
                "../../../models/payment/payment.php",
                "../../../models/arrears/arrears.php",
                "../../../controllers/payment/paymentController.php",
                "../../../utils/referenceGenerator.php",
                "../../../utils/check.php",
                "../../../encryption/encryption.php",
                "../../../Request/request.php",
                "../../../controllers/transaction/transactionController.php",
                "../../../models/transactions/transaction.php",
            );
            
            $allowed_includes = array(
                "../../../config/Connection.php",
                "../../../models/token/token.php",
                "../../../controllers/token/token.php",
                "../../../models/payment/payment.php",
                "../../../models/arrears/arrears.php",
                "../../../controllers/payment/paymentController.php",
                "../../../utils/referenceGenerator.php",
                "../../../utils/check.php",
                "../../../encryption/encryption.php",
                "../../../Request/request.php",
                "../../../controllers/transaction/transactionController.php",
                "../../../models/transactions/transaction.php",
            );
            
            $inc = new Blacklist();
            $inc->check($includes,$allowed_includes);
            
            $conn = new Connection();
            $conn = $conn->connects();


            $token = new TokenController($conn);
            $hasErrors = $token->verifyClient($authorization_secret);

            if($hasErrors['hasError'] == true){
                http_response_code(401);
                echo json_encode(array("Error" => "Access Rejected", "Description" => "Token not Provided"));
            }else{
            
            header("Access-Control-Allow-Origin: *");
            header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
            header("Access-Control-Max-Age: 6000");
            header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

            http_response_code(200);
            $request_method = $_SERVER["REQUEST_METHOD"];

            $allowed_methods = array("GET","POST","PUT");

// Checker instance
$check = new Check();

if($request_method == "GET"){

    $payment = new PaymentController($conn);
    if(isset($_GET['reference'])){
        $reference = $_GET['reference'];
        $data = array("reference" => $reference);
        $payment->getPayment($data);
    }else{
        
            $payment->getPayments();
        }
} else if($request_method == "POST"){

    // header("Content-Type: application/json; charset=UTF-8");
    // http_response_code(200);

    $paymentController = new PaymentController($conn)               ;
    $paymentController->createPayment();
        
    
} else if($request_method == "PUT"){
        

} else{
    if(!in_array($request_method,$allowed_methods)){
        echo json_encode(array("method"=>"Not Allowed"));
    }
}
            }
        }

    } // Auth check end

    else{
        echo json_encode(array("Error"=>"Authorization Not Accepted"));
    }

}

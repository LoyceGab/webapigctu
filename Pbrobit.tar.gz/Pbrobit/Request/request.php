<?php

class Request{
    private $method;
    private $postField;
    private $response;

    public function __construct($url,$method,$postField = null)
    {
        $curl = curl_init();
        curl_setopt_array($curl, array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => 'UTF-8',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 1000,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1
        ));

        if($method == "GET"){
            $this->method = $method;
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $this->method);

        }else if($method == "POST"){
            $this->method = $method;
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $this->method);
            $data = '';
            forEach($postField as $field => $value){
                $data .= "$field=$value&";
            }
            $data = substr($data,0,-1);
            curl_setopt($curl,CURLOPT_POSTFIELDS, $data);
            curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));
        }

        $this->response = curl_exec($curl);
        curl_close($curl);
    }

    public function __toString()
    {
        return $this->response;
    }
}

?>
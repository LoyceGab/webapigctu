<?php

class DBHelper{

    private $conn;
    private $result_count;

    public function __construct($conn)
    {
        $this->conn = $conn;
    }
    public function query($qry,$execute_options = null,$result=false){
        
        if(!empty($qry)){
        try {
            $query = $qry;
            $statement = $this->conn->prepare($query);
            $statement->execute($execute_options);
            if($result === true){
            $result = $statement->fetchAll(PDO::FETCH_ASSOC);
            $this->result_count = $statement->rowCount();
            return $result;
            //$this->row
            }

        } catch(PDOException $exception){
            echo $exception->getMessage();
        }
    }
    else{
        echo "Query not given";
        return array();
        }
    }

    public function resultCount(){
        if(!isset($this->result_count)){
            echo "Query was not made first";
            return null;
        }
        else{
            return $this->result_count;
        }
    }
}

?>
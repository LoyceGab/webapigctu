<?php
    class ReferenceGenerator{
        private $allowed_strings;
        private $reference;


        public function generate(){
            $this->allowed_strings = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
            $this->reference = substr(str_shuffle($this->allowed_strings),0,12);
            return $this->reference;
        }

        public function generateNumbers(){
            $this->allowed_strings = '0123456789';
            $this->reference = substr(str_shuffle($this->allowed_strings),0,6);
            return $this->reference;
        }
    }

?>
<?php

class Request{

    private $response;

    public function make($url,$method,$postfields){
                    $curl = curl_init();
                    curl_setopt_array($curl, array(
                    CURLOPT_URL => $url,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => 'UTF-8',
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 1000,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => $method
                    ));

                    if($method == "POST"){
                        curl_setopt($curl, CURLOPT_POSTFIELDS, $postfields);
                        curl_setopt($curl, CURLOPT_HTTPHEADER, array(
                            'Content-Type: application/x-www-form-urlencoded'
                        ));
                    }
                    $response = curl_exec($curl);
                    $this->response = $response;
                    curl_close($curl);
                    return $response;

    }

    public function getResponse(){      
        $output = json_decode($this->response,true);
        $data = array();
        foreach ($output as $key => $value) {
            $data[$key] = $value;
        }
        return $data;

    }
}

?>
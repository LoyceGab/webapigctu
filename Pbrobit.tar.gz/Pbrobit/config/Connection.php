<?php 

include "config.php";

class Connection{
    private $host;
    private $username;
    private $password;
    private $dbname;
    public $conn;


    public function __construct(){
        $this->host = host;
        $this->username = username;
        $this->password = password;
        $this->dbname = database;

    }

    public function connects(){
        $conn = null;
         try{
            $conn = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->dbname, $this->username, $this->password);
        }
        catch(PDOException $e){
            echo "Connection error:". $e->getMessage();
        }
            return $conn;
        }

}
?>
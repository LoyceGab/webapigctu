<?php

$connect = mysqli_connect("localhost","root", "", "ecomm");

if($connect){
    echo "Connected Successfully";
}
else{
    echo "Failed Connecting";
}
CREATE TABLE Authorization(
    id INT(50) AUTO_INCREMENT NOT NULL,
    reference VARCHAR(50) NULL,
    merchant_account_number VARCHAR(16) NULL,
    cardholder_account_number VARCHAR(16) NULL,
    amount INT(7) NULL,
    otp INT(6) NULL,
    confirmed VARCHAR(6) NULL,
    expires INT(3) NULL,
    date_created INT(20) NULL,
    PRIMARY KEY(id)
);
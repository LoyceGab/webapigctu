CREATE TABLE Accounts(
    id INT(50) AUTO_INCREMENT NOT NULL,
    reference VARCHAR(50) NULL,
    name VARCHAR(100) NULL,
    age INT(5) NULL,
    gender VARCHAR(10) NULL,
    phonenumber INT(20) NULL,
    email VARCHAR(100) NULL UNIQUE,
    address VARCHAR(100) NULL,
    account_type VARCHAR(30) NULL,
    account_number VARCHAR(16) NULL,
    card_type VARCHAR(15) NULL,
    card_number VARCHAR(16) NULL,
    card_expiry_month INT(5) NULL,
    card_expiry_year INT(5) NULL,
    card_cvv INT(3) NULL,
    card_pin INT(4) NULL,
    identity_type VARCHAR(25) NULL,
    identity_number VARCHAR(30) NULL,
    amount INT(10) NULL,
    currency VARCHAR(10) NULL,
    PRIMARY KEY(id)
);

-- Create a Sample CardHolder Account
INSERT INTO Accounts(reference,name,age,gender,phonenumber,email,address,account_type,account_number,card_type,card_number,card_expiry_month,card_expiry_year,card_cvv,card_pin,identity_type,identity_number,amount, currency)
VALUES("A001","Susuassey Wonder",22,"Male",0554513648,"susuasseymarvelousguy@gmail.com","P.O.BOX 77 AZ, Abozume-Biakor","Savings",5432123465765432,"Debit",4242424242424242,10,21,543,1234 ,"Voter Card",2322016969,1000,"GHC");
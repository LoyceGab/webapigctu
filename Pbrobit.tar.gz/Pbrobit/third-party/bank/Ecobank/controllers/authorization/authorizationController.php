<?php

class AuthorizationController{
    private $conn;

    public function __construct($conn)
    {
        $this->conn = $conn;
    }

    // After checking is done, update of authorization database is done
    public function checkAuthorization($data){
        $authorize = new AuthorizationModel($this->conn);
        $result = $authorize->checkAuthorization($data);

        $otp = $data['otp'];
        // echo $otp;

        forEach($result as $tdata){
            $otpData = $tdata['otp'];
        }

        if($otp == $otpData){
            // $this->updateAuthorization($cardholder_account_number);
            // A success of payment confirmed is sent to visa then to payment gateway
            $response = array(
                "Success" => "Payment Accepted",
                "Payment_status" => "Accepted"
            );
            return json_encode($response);
        }else{
            // update is not done and a failure message is sent to visa then to payment gateway
            $response = array(
                "Error" => "Payment Rejected",
                "Reason" => "CardHolder failed to confirm payment",
                "Payment_status" => "Refused"
            );
            return json_encode($response);
        }

    }

    public function checkAuthStatus($reference){
        $authorize = new AuthorizationModel($this->conn);
        $result = $authorize->checkAuthStatus($reference);
        forEach($result as $tdata){
            $status = $tdata['confirmed'];
        }
        return $status;
    }

    // After verification of account number and enough fund,
    // Authorization is created. Then the authorization UI is sent to checkAuthorization
    public function createAuthorization($data){
        $authorize = new AuthorizationModel($this->conn);
        $result = $authorize->createAuthorization($data);
        // forEach($result as $reference){
        //     $otpref = $reference["reference"];
        //     return $otpref;
        // }
        return $result;
        // $this->checkAuthorization($data);

        
    }

    // After the update of the database, report is sent to Visa which then sends to Payment Gateway
    private function updateAuthorization($data){
        $authorize = new AuthorizationModel($this->conn);
        $authorize->updateAuthorization($data);
    }
}
?>
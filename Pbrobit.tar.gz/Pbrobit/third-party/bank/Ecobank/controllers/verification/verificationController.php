<?php

class VerificationController{

    // Database
    private $conn;


    public function __construct($conn){
        $this->conn = $conn;
    }

    public function verifyCard($data){

        $verificationModel = new VerificationModel($this->conn);
        $result = $verificationModel->verifyCard($data);
        return $result;
        // echo json_encode($result);
    }

    public function checkBalance($data){
        $requested_amount = $data['amount'];
        $verificationModel = new VerificationModel($this->conn);
        $result = $verificationModel->checkBalance($data);
        forEach($result as $data){
            if($requested_amount <= $data['amount']){
                return true;
            }
            else{
                return false;
            }
        }
        // echo json_encode($result);
    }

    // After verifying, call the authorization endpoint and pass in the merchant's account number
    // and amount sent along with the payment request by the payment gateway.
}
?>
<?php
class VerificationModel{
    
    // Database
    private $conn;
    private $DBHelper;

    // Table
    private $table = "Accounts";


    public function __construct($conn){
        $this->conn = $conn;
        $this->DBHelper = new DBHelper($this->conn);
    }
    
    public function verifyCard($data){
        $card_number = $data['card_number'];
        $card_expiry_month = $data['card_expiry_month'];
        $card_expiry_year = $data['card_expiry_year'];
        $card_cvv = $data['card_cvv'];

        $selected_fields = "name,account_number";
        try {
            $query = "SELECT $selected_fields FROM $this->table WHERE card_number=:card_number AND card_expiry_month=:card_expiry_month AND card_expiry_year=:card_expiry_year AND card_cvv = :card_cvv";
            $statement = $this->conn->prepare($query);
            $statement->execute(
                array(
                ":card_number" => $card_number,
                ":card_expiry_month" => $card_expiry_month,
                ":card_expiry_year" => $card_expiry_year,
                ":card_cvv" => $card_cvv
                )
            );
            $result = $statement->fetchAll(PDO::FETCH_ASSOC);
            foreach ($result as $data) {
                $account_name = $data['name'];
                $account_number = $data['account_number'];
            }
            $result_count = $statement->rowCount();
            if($result_count == 1){
                $response = array("exists" => "true", "account_name" => "$account_name", "account_number" => "$account_number");
            }
            else{
                $response = array("exists" => "false");
            }
            return $response;

        } catch (PDOException $e) {
            echo $e->getMessage();
        }
    }

    public function checkBalance($data){
            $cardholder_account_number = $data['cardholder_account_number'];

            $query = "SELECT amount FROM $this->table WHERE account_number = :account_number";
            $execute_options = array(":account_number" => $cardholder_account_number);
            return $this->DBHelper->query($query,$execute_options,true);
            // try {
            //     // $query = 
            // } catch (PDOException $e) {
            //     echo $e->getMessage();
            // }
    }
}
?>
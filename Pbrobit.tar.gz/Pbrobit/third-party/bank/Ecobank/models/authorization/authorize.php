<?php 

class AuthorizationModel{

    private $table = "Authorization";
    private $conn;

    public function __construct($conn)
    {
        $this->conn = $conn;
    }

    public function createAuthorization($data){
        $referenceGenerator = new ReferenceGenerator();
        $otpGenerator = new OTPGenerator();
        
        $reference = $referenceGenerator->generate();
        $merchant_account_number = $data["merchant_account_number"];
        $cardholder_account_number = $data["cardholder_account_number"];
        $amount = $data["amount"];
        $otp = $otpGenerator->generate();
        $confirmed = "false";
        $expires = 120;
        $date_created = time();

        try {
            $query = "INSERT INTO $this->table(reference,merchant_account_number,cardholder_account_number,amount,otp,confirmed,expires,date_created)
                        VALUES(:reference,:merchant_account_number,:cardholder_account_number,:amount,:otp,:confirmed,:expires,:date_created)
            ";
            $statement = $this->conn->prepare($query);
            $statement->execute(
                array(
                    ":reference" => $reference,
                    ":merchant_account_number" => $merchant_account_number,
                    ":cardholder_account_number" => $cardholder_account_number,
                    ":amount" => $amount,
                    ":otp" => $otp,
                    ":confirmed" => $confirmed,
                    ":expires" => $expires,
                    ":date_created" => $date_created
                )
            );
            // return array("reference" => $reference);
            return $reference;
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
    }

    public function checkAuthorization($data){
        // Card holder provides otp sent to phone;
        $reference = $data['reference'];

        try {
            $query = "SELECT otp from $this->table WHERE reference = :reference";
            $statement = $this->conn->prepare($query);
            $statement->execute(
                array(":reference" => $reference)
            );
            return $statement->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            echo $e->getmessage();
        }
    }

    public function checkAuthStatus($reference){
        $ref = $reference;

        try {
            $query = "SELECT confirmed from $this->table WHERE reference = :reference";
            $statement = $this->conn->prepare($query);
            $statement->execute(
                array(":reference" => $ref)
            );
            return $statement->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            echo $e->getmessage();
        }
    }

    public function updateAuthorization($data){
        $cardholder_account_number = $data["cardholder_account_number"];
        $confirmed = "true";

        try {
            $query = "UPDATE $this->table SET confirmed = :confirmed WHERE cardholder_account_number=:cardholder_account_number";
            $statement = $this->conn->prepare($query);
            $result = $statement->execute(
                array(
                        ":confirmed" => $confirmed,
                        ":cardholder_account_number" => $cardholder_account_number
                    )
            );
            return $result;
        } catch (PDOException $e) {
            echo $e->getmessage();
        }
    }
}

?>
<?php
    class OTPGenerator{
        private $otp;


        public function generate(){
            $this->otp = random_int(100000,999999);
            return $this->otp;
        }
    }

?>
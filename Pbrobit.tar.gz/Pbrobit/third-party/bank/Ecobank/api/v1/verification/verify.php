<?php
header("Content-Type: application/json; charset=UTF-8");
require("../../../restriction/blacklist.php");

           $includes = array(
                "../../../config/Connection.php",
                "../../../models/authorization/authorize.php",
                "../../../models/verification/verification.php",
                "../../../controllers/authorization/authorizationController.php",
                "../../../controllers/verification/verificationController.php",
                "../../../utils/referenceGenerator.php",
                "../../../utils/check.php",
                "../../../encryption/encryption.php",
                "../../../DBHelper/dbhelper.php"
            );
            
            $allowed_includes = array(
                "../../../config/Connection.php",
                "../../../models/authorization/authorize.php",
                "../../../models/verification/verification.php",
                "../../../controllers/authorization/authorizationController.php",
                "../../../controllers/verification/verificationController.php",
                "../../../utils/referenceGenerator.php",
                "../../../utils/check.php",
                "../../../encryption/encryption.php",
                "../../../DBHelper/dbhelper.php"
            );
            
            $inc = new Blacklist();
            $inc->check($includes,$allowed_includes);
            
            $conn = new Connection();
            $conn = $conn->connects();
            header("Access-Control-Allow-Origin: http://localhost/Pbrobit/api/v1/");
            header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
            header("Access-Control-Max-Age: 6000");
            header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

            http_response_code(200);

            $request_method = $_SERVER["REQUEST_METHOD"];


            $uri = $_SERVER['REQUEST_URI'];
            $url = explode("/",$uri);

            $allowed_methods = array("POST");

            // Checker instance
            $check = new Check();

            
            if(in_array($request_method,$allowed_methods)){
                if($request_method == "GET"){
                    echo "Hello";
                }else if($request_method == "POST"){
        
                    $card_number= $check->check("card_number",true);
                    $card_expiry_month= $check->check("card_expiry_month",true);
                    $card_expiry_year= $check->check("card_expiry_year",true);
                    $card_cvv= $check->check("card_cvv",true);
            
                    // Required Parameters
                    $required = array($card_number,$card_expiry_month,$card_expiry_year,$card_cvv);
                    $validate = $check->validateRequired($required);
                    if($validate == true){
                        echo json_encode(array("Error" => "Some fields are required"));
                    }else{
                    $data = array(
                        "card_number" => $card_number,
                        "card_expiry_month" => $card_expiry_month,
                        "card_expiry_year" => $card_expiry_year,
                        "card_cvv" => $card_cvv
                    );
            
            
                $verification = new verificationController($conn);
                // echo json_encode($verification->verifyCard($data));
                $re = $verification->verifyCard($data);
                echo json_encode($re);
                    }
                
            } }
            else{ echo json_encode(array("method"=>"Not Allowed"));};

?>
<?php
header("Content-Type: application/json; charset=UTF-8");
require("../../../restriction/blacklist.php");

            $includes = array(
                "../../../config/Connection.php",
                "../../../models/authorization/authorize.php",
                "../../../controllers/authorization/authorizationController.php",
                "../../../controllers/verification/verificationController.php",
                "../../../models/verification/verification.php",
                "../../../utils/referenceGenerator.php",
                "../../../utils/otpGenerator.php",
                "../../../utils/check.php",
                "../../../encryption/encryption.php",
                "../../../DBHelper/dbhelper.php",
            );
            
            $allowed_includes = array(
                "../../../config/Connection.php",
                "../../../models/authorization/authorize.php",
                "../../../controllers/authorization/authorizationController.php",
                "../../../controllers/verification/verificationController.php",
                "../../../models/verification/verification.php",
                "../../../utils/referenceGenerator.php",
                "../../../utils/otpGenerator.php",
                "../../../utils/check.php",
                "../../../encryption/encryption.php",
                "../../../DBHelper/dbhelper.php",
            );
            
            $inc = new Blacklist();
            $inc->check($includes,$allowed_includes);
            
            $conn = new Connection();
            $conn = $conn->connects();
            header("Access-Control-Allow-Origin: http://localhost/Pbrobit/api/v1/");
            header("Access-Control-Allow-Methods: POST");
            header("Access-Control-Max-Age: 6000");
            header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
            header("cache: no-cache");

            http_response_code(200);

            $request_method = $_SERVER["REQUEST_METHOD"];


            $uri = $_SERVER['REQUEST_URI'];
            $url = explode("/",$uri);

            $allowed_methods = array("GET","POST");

            // Checker instance
            $check = new Check();

            if(in_array($request_method,$allowed_methods)){
            if($request_method == "GET"){
                echo json_encode(array("name" => "Susuassey Wonder", "age" => 22));
            }else if($request_method == "POST"){

                $merchant_account_number= $check->check("merchant_account_number",true);
                    $cardholder_account_number = $check->check("cardholder_account_number",true);
                    $amount= $check->check("amount",true);
            
                    // Required Parameters
                    $required = array($merchant_account_number,$cardholder_account_number,$amount);
                    $validate = $check->validateRequired($required);
                    if($validate == true){
                        echo json_encode(array("Error" => "Some fields are required"));
                    }else{
                    $data = array(
                        "merchant_account_number" => $merchant_account_number,
                        "cardholder_account_number" => $cardholder_account_number,
                        "amount" => $amount,
                    );

                    // Check if amount requested is less than amount in account before proceeding
                    $verificationController = new VerificationController($conn);
                    $checkBalance = $verificationController->checkBalance($data);
                    if($checkBalance == true){
                        $authorize = new AuthorizationController($conn);
                        $reference = $authorize->createAuthorization($data);
                        echo json_encode(array("status" => "Approved","otp_confirmation_link" => "http://localhost/project/Pbrobit/third-party/bank/Ecobank/views/authentication/authentication.php?reference=$reference"));
                    }
                    else{
                        echo json_encode(array("status" => "Declined","Description" => "Insufficient Fund"));
                    }
                    }
            } 
        }
            else{ echo json_encode(array("method"=>"Not Allowed"));};
?>
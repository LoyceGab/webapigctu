// fetch("www.pbrobit.com/thirdparty/card-schemes/visa/api/v1/authorization",
// {
//     method: "POST",
//     data: {

//     }
// });

var myHeaders = new Headers();
myHeaders.append("Content-Type", "application/x-www-form-urlencoded");

var urlencoded = new URLSearchParams();
urlencoded.append("merchant_account_number", "5122528942144942");
urlencoded.append("amount", "300");
urlencoded.append("card_number", "4242424242424242");
urlencoded.append("card_expiry_month", "10");
urlencoded.append("card_expiry_year", "21");
urlencoded.append("card_cvv", "543");

var requestOptions = {
  method: 'POST',
  headers: myHeaders,
  body: urlencoded,
  redirect: 'follow'
};

fetch("www.pbrobit.com/third-party/card-schemes/visa/api/v1/authorization/authorization", requestOptions)
  .then(response => response.text())
  .then(result => console.log(result))
  .catch(error => console.log('error', error));
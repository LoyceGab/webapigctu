<!-- SHows a screen or UI for card holders to confirm payment by using an otp sent to them -->
<?php 
// header("Content-Type: text/html");
// if(isset($_POST["confirm_payment_btn"])){
//     // require("../../config/Connection.php");
//     // require("../../controllers/authorization/authorizationController.php");
//     // require("../../models/authorization/authorize.php");
    
//     // $conn = new Connection();
//     // $conn = $conn->connects();
//     // $confirm_payment_pin = $_POST['confirm-payment-pin'];
    
//     // $auth = new AuthorizationController($conn);
//     // $data = array("otp" => $confirm_payment_pin,"reference" => $_GET["reference"]);
//     // $auth->checkAuthorization($data);

//     echo "Sa";
// }
// else{
//     echo "nah";
// }
// echo get_header()
// echo $_SERVER['HTTP_REFERER'];
    ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../public/css/styles.css">
    
    <title>Authorization</title>
</head>
<body>
    <main>
        <div class="container">

        <!-- Include "Verifies by VISA as well as logo for the bank of the CardHolder and in our case,
            its Ecobank" -->
            <form method="POST" action="auth" enctype="multipart/form-data">
                <header>
                    <h1 id="confirm-payment-title">Customer Online Transaction Confirmation</h1>
                </header>
                <p>
                    We sent you an OTP through SMS. <br>
                    Enter the Pin below to confirm the Transaction.
                </p>
                <input type="text" placeholder="One Time Pin" id="confirm-payment-pin" name="confirm-payment-pin" required> <br>
                <input type="hidden" name="referer" value="<?php echo $_SERVER['HTTP_REFERER'];?>"/>
                <input type="hidden" name="reference" value="<?php echo isset($_GET["reference"]) ? $_GET["reference"] : null; ?>"/>
                <input type="submit" value="Confirm Payment" id="confirm-payment-btn" name="confirm_payment_btn">
            </form>
        </div>
    </main>
</body>
</html>
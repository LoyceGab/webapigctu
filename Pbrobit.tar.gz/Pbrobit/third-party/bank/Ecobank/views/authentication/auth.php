<!-- SHows a screen or UI for card holders to confirm payment by using an otp sent to them -->
<?php 

    if(isset($_POST["confirm_payment_btn"])){
        require("../../config/Connection.php");
        require("../../controllers/authorization/authorizationController.php");
        require("../../models/authorization/authorize.php");
        
        $conn = new Connection();
        $conn = $conn->connects();
        $confirm_payment_pin = $_POST['confirm-payment-pin'];
        $reference = $_POST["reference"];
        $callback = $_POST["referer"];
        // echo $confirm_payment_pin;
        // var_dump($_POST);
        
        $auth = new AuthorizationController($conn);
        $data = array("otp" => $confirm_payment_pin,"reference" => $reference);
        $response = $auth->checkAuthorization($data);
        $res = json_decode($response,true);
        if($res["Payment_status"] == "Refused"){
                
        }else if($res["Payment_status"] == "Accepted"){
            header("Location: $callback");
        }


        // echo "<script>window.location = 'http://localhost:5000/home'</script>";
        // header("Location: $callback");
    }
    ?>
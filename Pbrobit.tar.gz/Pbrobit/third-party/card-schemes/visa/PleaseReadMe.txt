Visa will use two Apis in the process.
1. Verification Api - to verify account number or card holder information.
2. Authorization Api - to demand authorization of transaction from Bank Api


Verification Api takes the following:
Card Number
Card Expiry Month
Card Expiry Year
Card Cvv

The Verification Api calls the bank's verification api to check if details exist in database
The bank Api returns response to show existence of account information



Overview::
Payment gateway sends the payment information to the Visa Authorization Api.
The Visa Authorization Api calls the Visa Verification Api first to confirm if card information
is valid.

From the Card Number, Visa is able to know the bank the CardHolder is registered with.
(it means Visa database must have the various banks and and their associated Number) - This helps
Visa able to call the specific bank and make verification of card details.

The bank returns the response to Visa. If response is says card is valid,
Visa proceeds with their Authorization Api and sends the payment request to the 
specific bank api. The Bank Api then confirms the payment by:

1. Checking if CardHolder has enough fund for the amount requested to be paid for the transaction
If CardHolder has enough fund, the bank sends an otp to the CardHolder phone number or email address
The bank also sends the otp value as part of the response to Visa. Visa then forwards the response to
the payment gateway. Then the payment gateway shows the confirm otp page and expects the otp value
to be entered. If Otp is valid, Order Confirmed page is shown to user. Then the payment gateway
creates a transaction in the database.

However, if the cardholder doesn't have enough fund for payment, "Insufficient Fund in Account"
Error message is sent to Visa then to the Payment gateway and then to the merchant site which will
be presented to the cardholder. 

Note:: 
1.The payment gateway has to create a transaction once the payment fails.
2. The Payment Gateway also processes the response from visa before sending to merchant site


The Bank::
Has two Api...
1. Verification api which accesses the cardholders database to confirm information
2. Authorization api which checks the cardholder's account details to check to sufficient fund
and approves or declines the transaction. It sends otp to cardholder
It stores the Otp and few details about account into the Otp database.
Otp, approval of funds, reference to authorization approval

<?php

class AuthorizationController{

}


?>
<?php


// Verifies if the card is valid by check the next 5 number after the first one.
// It onlu checks if its a valid bank's cardnumber
class VerificationController{

    private $conn;


    public function __construct($conn)
    {
        $this->conn = $conn;
    }
    public function validateClient(){

        $verificationModel = new VerificationModel($this->conn);
        $result = $verificationModel->validateClient();
        
        foreach ($result as $data){
            $bin = $data['bin'];

            // Takes next five numbers after the first on the given card number and compares
            if($bin == 21342){
                return $data['bank_name'];
            }
        }
    }

}


?>
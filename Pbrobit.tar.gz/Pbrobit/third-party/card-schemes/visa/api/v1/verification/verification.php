<?php
header("Content-Type: application/json; charset=UTF-8");
require("../../../restriction/blacklist.php");

           $includes = array(
                "../../../config/Connection.php",
                "../../../models/authorization/authorize.php",
                "../../../models/verification/verification.php",
                "../../../controllers/authorization/authorizationController.php",
                "../../../controllers/verification/verificationController.php",
                "../../../utils/referenceGenerator.php",
                "../../../utils/check.php",
                "../../../encryption/encryption.php",
                "../../../DBHelper/dbhelper.php"
            );
            
            $allowed_includes = array(
                "../../../config/Connection.php",
                "../../../models/authorization/authorize.php",
                "../../../models/verification/verification.php",
                "../../../controllers/authorization/authorizationController.php",
                "../../../controllers/verification/verificationController.php",
                "../../../utils/referenceGenerator.php",
                "../../../utils/check.php",
                "../../../encryption/encryption.php",
                "../../../DBHelper/dbhelper.php"
            );
            
            $inc = new Blacklist();
            $inc->check($includes,$allowed_includes);
            
            $conn = new Connection();
            $conn = $conn->connects();
            header("Access-Control-Allow-Origin: http://localhost/Pbrobit/api/v1/");
            header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
            header("Access-Control-Max-Age: 6000");
            header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

            http_response_code(200);

            $request_method = $_SERVER["REQUEST_METHOD"];


            $uri = $_SERVER['REQUEST_URI'];
            $url = explode("/",$uri);

            $allowed_methods = array("GET","POST");

            // Checker instance
            $check = new Check();

            
            if(in_array($request_method,$allowed_methods)){
                if($request_method == "GET"){

                    $verification = new VerificationController($conn);
                    $bank = $verification->validateClient();
                    
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                    CURLOPT_URL => "www.pbrobit.com/third-party/bank/$bank/api/v1/authorization/authorize.php",
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => 'UTF-8',
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 0,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => 'GET',
                    ));

                    $response = curl_exec($curl);

                    curl_close($curl);
                    // $data = json_decode($response);
                    echo $response;

                }else if($request_method == "POST"){
        
                    $merchant_account_number = $check->check("merchant_account_number",true);
                    $amount= $check->check("amount",true);
                    $card_number= $check->check("card_number",true);
                    $card_expiry_month= $check->check("card_expiry_month",true);
                    $card_expiry_year= $check->check("card_expiry_year",true);
                    $card_cvv= $check->check("card_cvv",true);
            
                    // Required Parameters
                    $required = array($merchant_account_number,$amount,$card_number,$card_expiry_month,$card_expiry_year,$card_cvv);
                    $validate = $check->validateRequired($required);
                    if($validate == true){
                        echo json_encode(array("Error" => "Some fields are required"));
                    }else{
                    $data = array(
                        "merchant_account_number" => $merchant_account_number,
                        "amount" => $amount,
                        "card_number" => $card_number,
                        "card_expiry_month" => $card_expiry_month,
                        "card_expiry_year" => $card_expiry_year,
                        "card_cvv" => $card_cvv
                    );                

                        $verification = new VerificationController($conn);
                        $bank = $verification->validateClient();
                    
                    // Making call to the Visa verification Api
                    // Using Curl    
                    $curl = curl_init();
                    curl_setopt_array($curl, array(
                    CURLOPT_URL => "www.pbrobit.com/third-party/bank/$bank/api/v1/verification/verify",
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => 'UTF-8',
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 1000,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => 'POST',
                    CURLOPT_POSTFIELDS => "card_number=$card_number&card_expiry_month=$card_expiry_month&card_expiry_year=$card_expiry_year&card_cvv=$card_cvv",
                    CURLOPT_HTTPHEADER => array(
                        'Content-Type: application/x-www-form-urlencoded'
                    ),
                    ));

                    $response = curl_exec($curl);
                    $output = json_decode($response,true);
                    curl_close($curl);

                    // echo $response;

                    // Get response and decode
                    
                    $data = array();
                    foreach ($output as $key => $value) {
                        $data[$key] = $value;
                        // echo $data[$key];
                    }
                    $cardholder_account_number = isset($data["account_number"]) ? $data["account_number"] : null;

                    if($data["exists"] == "true"){    
                    
                    $curl = curl_init();
                    curl_setopt_array($curl, array(
                    CURLOPT_URL => "www.pbrobit.com/third-party/bank/$bank/api/v1/authorization/authorize",
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => 'UTF-8',
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 1000,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => 'POST',
                    CURLOPT_POSTFIELDS => "merchant_account_number=$merchant_account_number&amount=$amount&cardholder_account_number=$cardholder_account_number",
                    CURLOPT_HTTPHEADER => array(
                        'Content-Type: application/x-www-form-urlencoded'
                    ),
                    ));

                    $response = curl_exec($curl);
                    curl_close($curl);
                    echo $response;
                    // if($response != null){
                    //     header("Content-Type: text/html; charset=UTF-8");
                    //     require("../../../views/authentication/authentication.php");
                    // }
                    }else{
                        $response = array("exists" => "false");
                        echo json_encode($response);
                    }

                //    CURLOPT_POSTFIELDS => "merchant_account_number=$merchant_account_number&amount=$amount&card_number=$card_number&card_expiry_month=$card_expiry_month&card_expiry_year=$card_expiry_year&card_cvv=$card_cvv",
                }
                
            } }
            else{ echo json_encode(array("method"=>"Not Allowed"));};

?>
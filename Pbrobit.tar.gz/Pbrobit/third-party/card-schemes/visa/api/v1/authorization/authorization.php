<?php
header("Content-Type: application/json; charset=UTF-8");
require("../../../restriction/blacklist.php");

           $includes = array(
                "../../../config/Connection.php",
                "../../../models/authorization/authorize.php",
                "../../../models/verification/verification.php",
                "../../../controllers/authorization/authorizationController.php",
                "../../../controllers/verification/verificationController.php",
                "../../../utils/referenceGenerator.php",
                "../../../utils/check.php",
                "../../../encryption/encryption.php"
            );
            
            $allowed_includes = array(
                "../../../config/Connection.php",
                "../../../models/authorization/authorize.php",
                "../../../models/verification/verification.php",
                "../../../controllers/authorization/authorizationController.php",
                "../../../controllers/verification/verificationController.php",
                "../../../utils/referenceGenerator.php",
                "../../../utils/check.php",
                "../../../encryption/encryption.php"
            );
            
            $inc = new Blacklist();
            $inc->check($includes,$allowed_includes);
            
            $conn = new Connection();
            $conn = $conn->connects();
            header("Access-Control-Allow-Origin: http://localhost/Pbrobit/api/v1/");
            header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
            header("Access-Control-Max-Age: 6000");
            header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

            http_response_code(200);

            $request_method = $_SERVER["REQUEST_METHOD"];


            $uri = $_SERVER['REQUEST_URI'];
            $url = explode("/",$uri);

            $allowed_methods = array("GET","POST");

            // Checker instance
            $check = new Check();

            
            if(in_array($request_method,$allowed_methods)){
                if($request_method == "GET"){
                    
                    // $curl = curl_init();
                    // curl_setopt_array($curl, array(
                    // CURLOPT_URL => 'http://localhost/project/Pbrobit/third-party/bank/Ecobank/api/v1/authorization/authorize.php',
                    // CURLOPT_RETURNTRANSFER => true,
                    // CURLOPT_ENCODING => '',
                    // CURLOPT_MAXREDIRS => 10,
                    // CURLOPT_TIMEOUT => 0,
                    // CURLOPT_FOLLOWLOCATION => true,
                    // CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    // CURLOPT_CUSTOMREQUEST => 'GET',
                    // ));

                    // $response = curl_exec($curl);

                    // curl_close($curl);
                    // echo $response;


                    // header("Content-Type: application/json");
                    // echo json_encode(array("name" => "Prog"));


                }else if($request_method == "POST"){

                    if($_SERVER["CONTENT_TYPE"] === "application/json"){
                        $postData = json_decode(file_get_contents('php://input'), true);
                        $data = array();
                        foreach ($postData as $key => $value) {
                            $$key = $value;
                            }
                        }
                    else{
                        $merchant_account_number = $check->check("merchant_account_number");
                        $amount= $check->check("amount");
                        $card_number= $check->check("card_number");
                        $card_expiry_month= $check->check("card_expiry_month");
                        $card_expiry_year= $check->check("card_expiry_year");
                        $card_cvv= $check->check("card_cvv");
                    }


                    // Making call to the Visa verification Api
                    // Using Curl    
                        $curl = curl_init();
                        curl_setopt_array($curl, array(
                        CURLOPT_URL => 'www.pbrobit.com/third-party/card-schemes/visa/api/v1/verification/verification',
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_ENCODING => '',
                        CURLOPT_MAXREDIRS => 10,
                        CURLOPT_TIMEOUT => 0,
                        CURLOPT_FOLLOWLOCATION => true,
                        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                        CURLOPT_CUSTOMREQUEST => 'POST',
                        CURLOPT_POSTFIELDS => "merchant_account_number=$merchant_account_number&amount=$amount&card_number=$card_number&card_expiry_month=$card_expiry_month&card_expiry_year=$card_expiry_year&card_cvv=$card_cvv",
                        CURLOPT_HTTPHEADER => array(
                            'Content-Type: application/x-www-form-urlencoded'
                        ),
                        ));

                        $response = curl_exec($curl);

                        curl_close($curl);
                       echo $response;
                    

            
                    // Required Parameters
                    // $required = array($student_id,$depositor_name);
                    // $validate = $check->validateRequired($required);
                    // if($validate == true){
                    //     echo json_encode(array("Error" => "Some fields are required"));
                    // }else{
                    // $data = array(
                    //     "merchant_account_number" => $merchant_account_number,
                    //     "amount" => $amount,
                    //     "card_number" => $card_number,
                    //     "card_expiry_month" => $card_expiry_month,
                    //     "card_expiry_year" => $card_expiry_year,
                    //     "card_cvv" => $card_cvv
                    // );
            
            
                // $payment = new PaymentController($conn);
                // $payment->createPayment($data);
                    // }
                
            } }
            else{ echo json_encode(array("method"=>"Not Allowed"));};

?>
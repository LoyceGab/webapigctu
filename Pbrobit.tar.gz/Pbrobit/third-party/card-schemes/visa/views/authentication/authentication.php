<!-- SHows a screen or UI for card holders to confirm payment by using an otp sent to them -->
<?php 
    if(isset($_POST['confirm-payment-btn'])){
        // if(empty($_POST["confirm-payment-pin"])){
        //     echo ""
        // }
        $confirm_payment_pin = $_POST['confirm-payment-pin'];
        echo 

        // echo $confirm_payment_pin;
        require("auth.php");
        // $auth = new AuthorizationController($this->conn);
        // $data = array("otp" => $confirm_payment_pin);
        // $auth->checkAuthorization($data);
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../public/css/styles.css">
    <link rel="stylesheet" href="../../../views/public/css/styles.css">
    <title>Authorization</title>
</head>
<body>
    <main>
        <div class="container">

        <!-- Include "Verifies by VISA as well as logo for the bank of the CardHolder and in our case,
            its Ecobank" -->
            <form action="<?php $_SERVER['PHP_SELF']?>" method="POST" enctype="multipart/form-data">
                <header>
                    <h1 id="confirm-payment-title">Customer Online Transaction Confirmation</h1>
                </header>
                <p>
                    We sent you an OTP through SMS. <br>
                    Enter the Pin below to confirm the Transaction.
                </p>
                <input type="text" placeholder="One Time Pin" id="confirm-payment-pin" name="confirm-payment-pin" required> <br>
                <input type="submit" value="Confirm Payment" id="confirm-payment-btn" name="confirm-payment-btn">
            </form>
        </div>
    </main>
</body>
</html>
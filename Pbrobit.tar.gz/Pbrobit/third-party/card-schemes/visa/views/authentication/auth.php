<!-- SHows a screen or UI for card holders to confirm payment by using an otp sent to them -->
<?php 
    // if(isset($_POST['confirm-payment-btn'])){
    //     // if(empty($_POST["confirm-payment-pin"])){
    //     //     echo ""
    //     // }
    //     $confirm_payment_pin = $_POST['confirm-payment-pin'];

    //     echo $confirm_payment_pin;

    //     // $auth = new AuthorizationController($this->conn);
    //     // $data = array("otp" => $confirm_payment_pin);
    //     // echo $auth->checkAuthorization($data);
    // }

    echo "Prog";
?>
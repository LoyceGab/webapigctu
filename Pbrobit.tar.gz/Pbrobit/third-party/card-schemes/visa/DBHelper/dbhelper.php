<?php

class DBHelper{

    private $conn;

    public function __construct($conn)
    {
        $this->conn = $conn;
    }
    public function query($qry,$execute_options = null){
        
        if(!empty($qry)){
        try {
            $query = $qry;
            $statement = $this->conn->prepare($query);
            $statement->execute($execute_options);
            $result = $statement->fetchAll(PDO::FETCH_ASSOC);
            return $result;

        } catch(PDOException $exception){
            echo $exception->getMessage();
        }
    }
    else{
        echo "Query not given";
        return array();
        }
    }
}

?>
<?php
class VerificationModel{

    private $conn;
    private $DBHelper;

    private $table = "Banks";

    public function __construct($conn)
    {
        $this->conn = $conn;
        $this->DBHelper = new DBHelper($this->conn);
    }
    public function validateClient(){
        $query = "SELECT bin, bank_name FROM $this->table";
        return $this->DBHelper->query($query);
    }
}


?>
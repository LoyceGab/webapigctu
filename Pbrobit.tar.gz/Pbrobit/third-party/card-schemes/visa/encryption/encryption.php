<?php
header("Content-Type: application/json");
// Encryption taken from flutterwave page. Same in php.net
// Use it to encrypt the card information. Card {number, expiry and cvv}


// Sample Request to encryption server
// {
//     "card_number": "4242424242424242",
//     "cvv": "812",
//     "expiry_month": "01",
//     "expiry_year": "21",
//     "currency": "NGN",
//     "amount": "100000",
//     "email": "ekene@gmail.com",
//     "tx_ref": "MC-3243enewtest-visa-2",
//     "redirect_url": "https://webhook.site/3ed41e38-2c79-4c79-b455-97398730866c",
//     "type": "card"
// }

// Sample Response from encryption server
// {
//     "client": "C10EgEYkJrusinoq55RgQ7rl+hlselSCuuX6GWx6VIJ7Ec7hXCGXup9Ukx8Luge/2HH2WYqXHvqdgrwMxhwlFMUV7tgqgH9ZCoe37pCnvkSkToNPiAbU0jG7L5i+WCxVR5/RaF0p0wbts8nb291rlgpnkk7QPuI2HcqR9R5Uairt/0O+PEmmFhF9v9A92X1w3zyAsGKQH98XxJxP9tAn176RahJL0upUhxrkJHoyJdaE55iicZGpg7Gu/CMYkgQHBGj3ODzL4Bla+pO+50wh5j2BIR+yjx8/V6uMw0qEPvfi5w+zQMoyQhFKvaYxk9P23L+SqR1tBzkty/aV4SCwLmpnzQnbXUewBqxZTQH+1MI="
// }

// The encrypted data is then sent to the charges api to make direct charges


// NOTE:: only use this if you want to send the card details from the client to the payment gateway
// But you can use it to encrypt the card details on the payment gateway before storing it into database


class Encrypt{

   private $key = "PbrobitCardEncrypt";
   private $method = 'DES-EDE3';
   
   public function encrypt3Des($data){

      $encData = openssl_encrypt($data, $this->method, $this->key, OPENSSL_RAW_DATA);
      return base64_encode($encData); 
   }

   public function decrypt3Des($encData){
      return openssl_decrypt($encData,$this->method,$this->key);
   }
}


// Sample Encryption
// $data = "Hello Prof";
// $sample = new Encrypt();
// $enc_data = $sample->encrypt3Des($data);
// echo $enc_data;

?>
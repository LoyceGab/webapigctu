CREATE TABLE Banks(
    id INT(50) AUTO_INCREMENT NOT NULL,
    reference VARCHAR(50) NULL,
    bin INT(5) NULL,
    bank_name VARCHAR(255) NULL,
    PRIMARY KEY(id)
);


INSERT INTO Banks(reference,bin,bank_name) VALUES("53sq",21342,"Ecobank"),("12sa",12348,"GCB");

-- bin - Bank Identification Number
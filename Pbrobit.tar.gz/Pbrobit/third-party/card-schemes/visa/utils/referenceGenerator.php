<?php
    class ReferenceGenerator{
        private $allowed_strings;
        private $reference;


        public function generate(){
            $this->allowed_strings = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
            $this->reference = substr(str_shuffle($this->allowed_strings),0,12);
            return $this->reference;
        }
    }

?>
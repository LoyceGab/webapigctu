<?php
    class Check{
        private $key;

        public function check($key,$required=false){
            if($required == false){
                return $this->notRequired($key);
            }
            else {
                return $this->isRequired($key);
            }
        }


        private function isRequired($key){
            $this->key = $key;
            if(!isset($_POST[$this->key]) || empty($_POST[$this->key])){
                return $this->hasErrors();
            } else{
            $this->key = $_POST[$this->key];
            return $this->key;
            }
        }
        private function notRequired($key){
            $this->key = $key;
            if(!isset($_POST[$this->key])){
                $this->key = null;
                return $this->key;
            }else if(empty($_POST[$this->key])){
                $this->key = "";
                return $this->key;
            }
            else{
                $this->key = $_POST[$this->key];
                return $this->key;
                }
        }

        private function hasErrors(){
            $hasErrors = true;
            return $hasErrors;
        }

        public function validateRequired($requiredFields){
            $requiredFieldsValue = array();
            forEach($requiredFields as $required){
                if($required === true){
                    $result = true;
                    array_push($requiredFieldsValue,$result);
                }
                else{
                    $result = false;
                    array_push($requiredFieldsValue,$result);
                }
            }

            if(in_array(true, $requiredFieldsValue)){
                return true;
            }
            else{
                return false;
            }
        }
    }
?>
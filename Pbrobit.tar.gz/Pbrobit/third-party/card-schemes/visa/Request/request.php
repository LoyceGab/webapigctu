<?php

class Request{
    private $method;
    private $postField;

    public function __construct($url,$method,$postField = null)
    {
        // $this->postField = $postField;
        $curl = curl_init();
        curl_setopt_array($curl, array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => 'UTF-8',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 1000,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1
        ));

        // $output = json_decode($response,true);

        if($method == "GET"){
            $this->method = $method;
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $this->method);

        }else if($method == "POST"){
            $this->method = $method;
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $this->method);
            $data = '';
            forEach($postField as $field){
                $data .= "$$field=$$field&";
            }
            $data = substr($data,0,-1);
            curl_setopt($curl,CURLOPT_POSTFIELDS, $data);
            curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded'));
        }

        $response = curl_exec($curl);
        curl_close($curl);
        echo $response;
    }
}

// CURLOPT_POSTFIELDS => "card_number=$card_number&card_expiry_month=$card_expiry_month&card_expiry_year=$card_expiry_year&card_cvv=$card_cvv",

// $request = new Request("google.com","POST",array("card_number","card_cvv"));

?>
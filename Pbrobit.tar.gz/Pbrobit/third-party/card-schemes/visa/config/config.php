<?php 
    // Information here shouldn't be exposed but since its not sensitive enough,
    // it has been made available
    
    define("host","localhost");
    define("username","root");
    define("password","");
    define("database","Pbrobit");

?>
